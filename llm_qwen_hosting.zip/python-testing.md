python testing pytest unittest

When writing Python code that will be tested or verified:
- Always include a `if __name__ == "__main__":` block for scripts, or a corresponding test file for libraries.
- Prefer plain `assert` statements for quick sanity checks before reaching for pytest.
- After writing a file, run it (or import it) to catch syntax errors immediately rather than assuming it's correct.
- Keep functions small and pure where possible — easier to test in isolation.
