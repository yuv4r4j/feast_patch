"""
Minimal local coding agent POC.
Talks to a local llama.cpp server (OpenAI-compatible /v1/chat/completions).
No framework — just the loop, so you can see exactly what's happening.
"""

import json
import os
import subprocess
import sys
from pathlib import Path
import requests

LLAMA_SERVER_URL = os.environ.get(
    "LLAMA_SERVER_URL", "http://localhost:8080/v1/chat/completions"
)
# In-cluster this is usually a ConfigMap mounted at /app/skills-mounted;
# falls back to the baked-in skills/ dir for local testing.
SKILLS_DIR = Path(os.environ.get("SKILLS_DIR", str(Path(__file__).parent / "skills")))

# ---- Tools the agent can call -------------------------------------------

def run_shell(command: str) -> str:
    result = subprocess.run(
        command, shell=True, capture_output=True, text=True, timeout=60
    )
    return f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}\nexit_code:{result.returncode}"


def read_file(path: str) -> str:
    try:
        return Path(path).read_text()
    except Exception as e:
        return f"error reading {path}: {e}"


def write_file(path: str, content: str) -> str:
    try:
        Path(path).write_text(content)
        return f"wrote {len(content)} chars to {path}"
    except Exception as e:
        return f"error writing {path}: {e}"


TOOLS = {
    "run_shell": run_shell,
    "read_file": read_file,
    "write_file": write_file,
}

TOOL_SCHEMAS = [
    {
        "type": "function",
        "function": {
            "name": "run_shell",
            "description": "Run a shell command and return stdout/stderr/exit code.",
            "parameters": {
                "type": "object",
                "properties": {"command": {"type": "string"}},
                "required": ["command"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Read the contents of a file.",
            "parameters": {
                "type": "object",
                "properties": {"path": {"type": "string"}},
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": "Write content to a file, overwriting it.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string"},
                    "content": {"type": "string"},
                },
                "required": ["path", "content"],
            },
        },
    },
]

# ---- Skill loading (keyword match, no vector DB needed for POC) ---------

def load_relevant_skills(user_request: str, max_skills: int = 2) -> str:
    """Very simple keyword overlap match against skill filenames + first line."""
    if not SKILLS_DIR.exists():
        return ""
    scored = []
    words = set(user_request.lower().split())
    for skill_file in SKILLS_DIR.glob("*.md"):
        text = skill_file.read_text()
        first_line = text.splitlines()[0] if text else ""
        skill_words = set((skill_file.stem + " " + first_line).lower().split())
        overlap = len(words & skill_words)
        if overlap > 0:
            scored.append((overlap, skill_file, text))
    scored.sort(key=lambda x: -x[0])
    chosen = scored[:max_skills]
    if not chosen:
        return ""
    return "\n\n".join(f"# Skill: {f.stem}\n{text}" for _, f, text in chosen)


# ---- Agent loop -----------------------------------------------------------

def run_agent(user_request: str, max_turns: int = 10):
    skill_context = load_relevant_skills(user_request)
    system_prompt = "You are a local coding agent. Use tools to accomplish the task."
    if skill_context:
        system_prompt += f"\n\nRelevant skill instructions:\n{skill_context}"

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_request},
    ]

    for turn in range(max_turns):
        resp = requests.post(
            LLAMA_SERVER_URL,
            json={
                "model": "local",
                "messages": messages,
                "tools": TOOL_SCHEMAS,
                "temperature": 0.2,
            },
            timeout=300,
        )
        resp.raise_for_status()
        choice = resp.json()["choices"][0]
        msg = choice["message"]
        messages.append(msg)

        tool_calls = msg.get("tool_calls")
        if not tool_calls:
            print(f"\n[final answer, turn {turn}]\n{msg.get('content')}")
            return msg.get("content")

        for call in tool_calls:
            name = call["function"]["name"]
            args = json.loads(call["function"]["arguments"])
            print(f"\n[turn {turn}] calling {name}({args})")
            result = TOOLS[name](**args)
            print(f"[result] {result[:300]}")
            messages.append(
                {
                    "role": "tool",
                    "tool_call_id": call["id"],
                    "content": result,
                }
            )

    print("hit max_turns without finishing")
    return None


if __name__ == "__main__":
    # In-container this runs once per Job/Pod: task comes from argv or TASK env var.
    if len(sys.argv) > 1:
        task = " ".join(sys.argv[1:])
    else:
        task = os.environ.get(
            "TASK",
            "Write a Python function that reverses a linked list, save it to "
            "reverse_ll.py, then run it to check it imports cleanly.",
        )
    run_agent(task)
