#!/bin/bash
# Build both images against OpenShift's internal registry and apply manifests.
# Assumes: oc login already done, and you're in the target project/namespace.
set -euo pipefail

NAMESPACE=$(oc project -q)
REGISTRY=$(oc registry info --internal 2>/dev/null || echo "image-registry.openshift-image-registry.svc:5000")

echo "== Building llm-server image =="
oc new-build --binary --strategy=docker --name=llm-server -n "$NAMESPACE" || true
oc start-build llm-server --from-dir=./llm-server --follow -n "$NAMESPACE"

echo "== Building agent image =="
oc new-build --binary --strategy=docker --name=agent -n "$NAMESPACE" || true
oc start-build agent --from-dir=./agent --follow -n "$NAMESPACE"

echo "== Patching manifests with in-cluster image refs =="
sed "s#<YOUR_REGISTRY>/llm-server:latest#${REGISTRY}/${NAMESPACE}/llm-server:latest#" \
  k8s/llm-server-deployment.yaml > /tmp/llm-server-deployment.yaml
sed "s#<YOUR_REGISTRY>/agent:latest#${REGISTRY}/${NAMESPACE}/agent:latest#" \
  k8s/agent-job.yaml > /tmp/agent-job.yaml

echo "== Applying PVC, ConfigMap =="
oc apply -f k8s/model-pvc.yaml
oc apply -f k8s/agent-skills-configmap.yaml

echo "== Downloading model into PVC (one-time, edit the Job to change model) =="
oc apply -f k8s/model-loader-job.yaml
echo "   waiting for model download to finish (this can take a while)..."
oc wait --for=condition=complete job/model-loader --timeout=3600s

echo "== Deploying llm-server =="
oc apply -f /tmp/llm-server-deployment.yaml
oc rollout status deployment/llm-server

echo "== Done. Run a task with: =="
echo "   oc create -f /tmp/agent-job.yaml"
echo "   oc logs -f job/<generated-name>"
