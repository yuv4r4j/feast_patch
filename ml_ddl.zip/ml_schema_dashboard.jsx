import { useState, useEffect, useCallback, useRef } from "react";

const SCHEMA = {
  "Experiment & Project Layer": {
    color: "#E8BF44",
    tables: {
      ml_project: {
        description: "Top-level organizational unit for ML initiatives",
        columns: [
          { name: "project_id", type: "SERIAL", pk: true },
          { name: "project_name", type: "VARCHAR(256)", nullable: false },
          { name: "project_code", type: "VARCHAR(64)", nullable: false, unique: true },
          { name: "description", type: "TEXT" },
          { name: "business_unit", type: "VARCHAR(128)" },
          { name: "department_name", type: "VARCHAR(128)" },
          { name: "project_owner", type: "VARCHAR(256)" },
          { name: "email_id", type: "VARCHAR(256)" },
          { name: "project_type", type: "VARCHAR(64)", note: "classification | regression | clustering | forecasting | anomaly_detection | recommender" },
          { name: "risk_tier", type: "VARCHAR(32)", note: "SR11-7 model risk: critical | high | medium | low" },
          { name: "regulatory_scope", type: "VARCHAR(128)", note: "e.g., CECL, CCAR, IFRS9, Basel" },
          { name: "is_active", type: "BOOLEAN", default: "true" },
          { name: "created_date", type: "TIMESTAMP" },
          { name: "created_by", type: "VARCHAR(128)" },
          { name: "updated_date", type: "TIMESTAMP" },
          { name: "updated_by", type: "VARCHAR(128)" },
        ],
      },
      ml_experiment: {
        description: "Logical grouping of runs under a project (e.g., 'PD Model v3 — LightGBM sweep')",
        columns: [
          { name: "experiment_id", type: "SERIAL", pk: true },
          { name: "project_id", type: "INTEGER", fk: "ml_project.project_id", nullable: false },
          { name: "experiment_name", type: "VARCHAR(256)", nullable: false },
          { name: "experiment_code", type: "VARCHAR(128)", unique: true },
          { name: "hypothesis", type: "TEXT" },
          { name: "objective_metric", type: "VARCHAR(128)", note: "Primary metric: AUC, RMSE, Gini, KS, etc." },
          { name: "objective_direction", type: "VARCHAR(16)", note: "minimize | maximize" },
          { name: "baseline_metric_value", type: "NUMERIC(18,6)" },
          { name: "tags", type: "JSONB" },
          { name: "is_active", type: "BOOLEAN", default: "true" },
          { name: "created_date", type: "TIMESTAMP" },
          { name: "created_by", type: "VARCHAR(128)" },
          { name: "updated_date", type: "TIMESTAMP" },
          { name: "updated_by", type: "VARCHAR(128)" },
        ],
      },
      ml_experiment_run: {
        description: "Single execution of an experiment (maps to MLflow run_id)",
        columns: [
          { name: "run_id", type: "SERIAL", pk: true },
          { name: "experiment_id", type: "INTEGER", fk: "ml_experiment.experiment_id", nullable: false },
          { name: "run_uuid", type: "UUID", nullable: false, unique: true, note: "Correlate with MLflow run_id" },
          { name: "parent_run_id", type: "INTEGER", fk: "ml_experiment_run.run_id", note: "For nested / child runs" },
          { name: "run_name", type: "VARCHAR(256)" },
          { name: "run_status", type: "VARCHAR(32)", nullable: false, note: "queued | running | completed | failed | killed | timeout" },
          { name: "trigger_type", type: "VARCHAR(32)", note: "manual | scheduled | ci_cd | drift_alert | retrain" },
          { name: "git_commit_sha", type: "VARCHAR(64)" },
          { name: "git_branch", type: "VARCHAR(256)" },
          { name: "git_repo_url", type: "VARCHAR(512)" },
          { name: "docker_image_uri", type: "VARCHAR(512)" },
          { name: "entry_point", type: "VARCHAR(512)", note: "Script or module path" },
          { name: "hyperparameters", type: "JSONB" },
          { name: "metrics", type: "JSONB", note: "{auc: 0.87, ks: 0.45, gini: 0.74}" },
          { name: "start_time", type: "TIMESTAMP" },
          { name: "end_time", type: "TIMESTAMP" },
          { name: "duration_seconds", type: "INTEGER" },
          { name: "error_message", type: "TEXT" },
          { name: "error_traceback", type: "TEXT" },
          { name: "tags", type: "JSONB" },
          { name: "created_date", type: "TIMESTAMP" },
          { name: "created_by", type: "VARCHAR(128)" },
          { name: "updated_date", type: "TIMESTAMP" },
          { name: "updated_by", type: "VARCHAR(128)" },
        ],
      },
    },
  },
  "Model Registry & Artifacts": {
    color: "#5BA37E",
    tables: {
      ml_model_registry: {
        description: "Canonical model entry — one row per logical model (e.g., 'PD Scorecard - Retail')",
        columns: [
          { name: "model_id", type: "SERIAL", pk: true },
          { name: "project_id", type: "INTEGER", fk: "ml_project.project_id", nullable: false },
          { name: "model_name", type: "VARCHAR(256)", nullable: false },
          { name: "model_code", type: "VARCHAR(128)", unique: true },
          { name: "model_type", type: "VARCHAR(64)", note: "logistic_regression | xgboost | lightgbm | neural_net | ensemble | custom" },
          { name: "framework", type: "VARCHAR(64)", note: "sklearn | spark_ml | pytorch | tensorflow | xgboost | custom" },
          { name: "description", type: "TEXT" },
          { name: "model_owner", type: "VARCHAR(256)" },
          { name: "model_risk_rating", type: "VARCHAR(32)", note: "SR11-7: critical | high | medium | low" },
          { name: "is_active", type: "BOOLEAN", default: "true" },
          { name: "created_date", type: "TIMESTAMP" },
          { name: "created_by", type: "VARCHAR(128)" },
          { name: "updated_date", type: "TIMESTAMP" },
          { name: "updated_by", type: "VARCHAR(128)" },
        ],
      },
      ml_model_version: {
        description: "Immutable snapshot of a trained model — tied to a specific run",
        columns: [
          { name: "model_version_id", type: "SERIAL", pk: true },
          { name: "model_id", type: "INTEGER", fk: "ml_model_registry.model_id", nullable: false },
          { name: "run_id", type: "INTEGER", fk: "ml_experiment_run.run_id", nullable: false },
          { name: "version_number", type: "INTEGER", nullable: false },
          { name: "stage", type: "VARCHAR(32)", nullable: false, note: "development | staging | champion | challenger | archived | retired" },
          { name: "promoted_date", type: "TIMESTAMP" },
          { name: "promoted_by", type: "VARCHAR(128)" },
          { name: "approval_status", type: "VARCHAR(32)", note: "pending | approved | rejected" },
          { name: "approved_by", type: "VARCHAR(128)" },
          { name: "approval_date", type: "TIMESTAMP" },
          { name: "approval_notes", type: "TEXT" },
          { name: "model_signature", type: "JSONB", note: "Input/output schema" },
          { name: "feature_importance", type: "JSONB" },
          { name: "training_dataset_id", type: "INTEGER", fk: "ml_dataset_registry.dataset_id" },
          { name: "validation_dataset_id", type: "INTEGER", fk: "ml_dataset_registry.dataset_id" },
          { name: "metrics_snapshot", type: "JSONB" },
          { name: "is_active", type: "BOOLEAN", default: "true" },
          { name: "created_date", type: "TIMESTAMP" },
          { name: "created_by", type: "VARCHAR(128)" },
          { name: "updated_date", type: "TIMESTAMP" },
          { name: "updated_by", type: "VARCHAR(128)" },
        ],
      },
      ml_model_artifact: {
        description: "Physical artifact storage references (serialized model, ONNX, PMML, etc.)",
        columns: [
          { name: "artifact_id", type: "SERIAL", pk: true },
          { name: "model_version_id", type: "INTEGER", fk: "ml_model_version.model_version_id", nullable: false },
          { name: "artifact_type", type: "VARCHAR(64)", nullable: false, note: "model_binary | onnx | pmml | feature_encoder | scaler | tokenizer | config" },
          { name: "artifact_uri", type: "VARCHAR(1024)", nullable: false, note: "s3:// or cdfs:// path" },
          { name: "artifact_format", type: "VARCHAR(64)", note: "pickle | joblib | onnx | pmml | safetensors | h5" },
          { name: "file_size_bytes", type: "BIGINT" },
          { name: "checksum_sha256", type: "VARCHAR(64)" },
          { name: "is_active", type: "BOOLEAN", default: "true" },
          { name: "created_date", type: "TIMESTAMP" },
          { name: "created_by", type: "VARCHAR(128)" },
        ],
      },
    },
  },
  "Pipeline & Execution Layer": {
    color: "#4A8FCC",
    tables: {
      ml_pipeline_definition: {
        description: "Reusable pipeline template — DAG of steps for training, scoring, retraining",
        columns: [
          { name: "pipeline_id", type: "SERIAL", pk: true },
          { name: "project_id", type: "INTEGER", fk: "ml_project.project_id" },
          { name: "pipeline_name", type: "VARCHAR(256)", nullable: false },
          { name: "pipeline_code", type: "VARCHAR(128)", unique: true },
          { name: "pipeline_type", type: "VARCHAR(64)", nullable: false, note: "training | scoring | retraining | feature_engineering | evaluation | etl_ml" },
          { name: "description", type: "TEXT" },
          { name: "dag_definition", type: "JSONB", note: "Step dependency graph" },
          { name: "default_compute_config_id", type: "INTEGER", fk: "ml_compute_config.compute_config_id" },
          { name: "retry_policy", type: "JSONB", note: "{max_retries: 3, backoff_seconds: 60}" },
          { name: "timeout_minutes", type: "INTEGER", default: "360" },
          { name: "notification_email_id", type: "VARCHAR(256)" },
          { name: "version", type: "INTEGER", default: "1" },
          { name: "is_active", type: "BOOLEAN", default: "true" },
          { name: "created_date", type: "TIMESTAMP" },
          { name: "created_by", type: "VARCHAR(128)" },
          { name: "updated_date", type: "TIMESTAMP" },
          { name: "updated_by", type: "VARCHAR(128)" },
        ],
      },
      ml_pipeline_step: {
        description: "Individual step within a pipeline DAG",
        columns: [
          { name: "step_id", type: "SERIAL", pk: true },
          { name: "pipeline_id", type: "INTEGER", fk: "ml_pipeline_definition.pipeline_id", nullable: false },
          { name: "step_name", type: "VARCHAR(256)", nullable: false },
          { name: "step_order", type: "INTEGER", nullable: false },
          { name: "step_type", type: "VARCHAR(64)", nullable: false, note: "data_pull | feature_eng | train | evaluate | register | deploy | quality_check | custom" },
          { name: "entry_point", type: "VARCHAR(512)" },
          { name: "step_parameters", type: "JSONB" },
          { name: "depends_on_steps", type: "INTEGER[]", note: "Array of step_ids this step depends on" },
          { name: "compute_config_id", type: "INTEGER", fk: "ml_compute_config.compute_config_id", note: "Override pipeline default" },
          { name: "timeout_minutes", type: "INTEGER" },
          { name: "is_optional", type: "BOOLEAN", default: "false" },
          { name: "is_active", type: "BOOLEAN", default: "true" },
          { name: "created_date", type: "TIMESTAMP" },
          { name: "created_by", type: "VARCHAR(128)" },
        ],
      },
      ml_pipeline_execution: {
        description: "Runtime instance of a pipeline — tracks full execution lifecycle",
        columns: [
          { name: "execution_id", type: "SERIAL", pk: true },
          { name: "pipeline_id", type: "INTEGER", fk: "ml_pipeline_definition.pipeline_id", nullable: false },
          { name: "run_id", type: "INTEGER", fk: "ml_experiment_run.run_id" },
          { name: "execution_uuid", type: "UUID", unique: true, nullable: false },
          { name: "execution_status", type: "VARCHAR(32)", nullable: false, note: "queued | running | completed | failed | killed | timeout | partial_success" },
          { name: "trigger_type", type: "VARCHAR(32)", note: "manual | scheduled | event | drift_alert | api" },
          { name: "triggered_by", type: "VARCHAR(128)" },
          { name: "schedule_id", type: "INTEGER", fk: "ml_schedule_config.schedule_id" },
          { name: "runtime_parameters", type: "JSONB" },
          { name: "start_time", type: "TIMESTAMP" },
          { name: "end_time", type: "TIMESTAMP" },
          { name: "duration_seconds", type: "INTEGER" },
          { name: "steps_total", type: "INTEGER" },
          { name: "steps_completed", type: "INTEGER" },
          { name: "steps_failed", type: "INTEGER" },
          { name: "error_message", type: "TEXT" },
          { name: "resource_usage", type: "JSONB", note: "{peak_memory_gb, cpu_hours, gpu_hours}" },
          { name: "created_date", type: "TIMESTAMP" },
          { name: "created_by", type: "VARCHAR(128)" },
          { name: "updated_date", type: "TIMESTAMP" },
          { name: "updated_by", type: "VARCHAR(128)" },
        ],
      },
      ml_step_execution: {
        description: "Runtime details for each step within a pipeline execution",
        columns: [
          { name: "step_execution_id", type: "SERIAL", pk: true },
          { name: "execution_id", type: "INTEGER", fk: "ml_pipeline_execution.execution_id", nullable: false },
          { name: "step_id", type: "INTEGER", fk: "ml_pipeline_step.step_id", nullable: false },
          { name: "step_status", type: "VARCHAR(32)", nullable: false, note: "queued | running | completed | failed | skipped | timeout" },
          { name: "attempt_number", type: "INTEGER", default: "1" },
          { name: "input_artifact_uris", type: "JSONB" },
          { name: "output_artifact_uris", type: "JSONB" },
          { name: "step_metrics", type: "JSONB" },
          { name: "step_logs_uri", type: "VARCHAR(1024)" },
          { name: "start_time", type: "TIMESTAMP" },
          { name: "end_time", type: "TIMESTAMP" },
          { name: "duration_seconds", type: "INTEGER" },
          { name: "error_message", type: "TEXT" },
          { name: "error_traceback", type: "TEXT" },
          { name: "resource_usage", type: "JSONB" },
          { name: "created_date", type: "TIMESTAMP" },
          { name: "created_by", type: "VARCHAR(128)" },
        ],
      },
    },
  },
  "Compute & Infrastructure": {
    color: "#9B6DB5",
    tables: {
      ml_compute_config: {
        description: "Compute resource templates — mirrors your spark_submit_setting pattern",
        columns: [
          { name: "compute_config_id", type: "SERIAL", pk: true },
          { name: "config_name", type: "VARCHAR(256)", nullable: false },
          { name: "config_code", type: "VARCHAR(128)", unique: true },
          { name: "compute_type", type: "VARCHAR(64)", nullable: false, note: "spark | kubernetes | single_node | gpu_cluster | serverless" },
          { name: "cluster_namespace", type: "VARCHAR(128)", note: "OpenShift/K8s namespace" },
          { name: "exec_instances", type: "INTEGER", note: "Spark executors or pod replicas" },
          { name: "exec_cores", type: "INTEGER" },
          { name: "exec_mem", type: "VARCHAR(32)", note: "e.g., 8g, 16g" },
          { name: "driver_cores", type: "INTEGER" },
          { name: "driver_mem", type: "VARCHAR(32)" },
          { name: "pyspark_mem", type: "VARCHAR(32)", note: "spark.executor.pyspark.memory" },
          { name: "gpu_type", type: "VARCHAR(64)", note: "nvidia-t4 | nvidia-a100 | none" },
          { name: "gpu_count", type: "INTEGER", default: "0" },
          { name: "spark_conf_overrides", type: "JSONB" },
          { name: "env_variables", type: "JSONB" },
          { name: "docker_image_uri", type: "VARCHAR(512)" },
          { name: "resource_quota_cpu", type: "VARCHAR(32)" },
          { name: "resource_quota_memory", type: "VARCHAR(32)" },
          { name: "is_active", type: "BOOLEAN", default: "true" },
          { name: "created_date", type: "TIMESTAMP" },
          { name: "created_by", type: "VARCHAR(128)" },
          { name: "updated_date", type: "TIMESTAMP" },
          { name: "updated_by", type: "VARCHAR(128)" },
        ],
      },
      ml_schedule_config: {
        description: "Cron-based or event-driven scheduling for pipeline executions",
        columns: [
          { name: "schedule_id", type: "SERIAL", pk: true },
          { name: "pipeline_id", type: "INTEGER", fk: "ml_pipeline_definition.pipeline_id", nullable: false },
          { name: "schedule_name", type: "VARCHAR(256)" },
          { name: "schedule_type", type: "VARCHAR(32)", nullable: false, note: "cron | event | on_demand" },
          { name: "cron_expression", type: "VARCHAR(128)" },
          { name: "event_trigger", type: "JSONB", note: "{type: 'feed_complete', feed_id: 8}" },
          { name: "timezone", type: "VARCHAR(64)", default: "'UTC'" },
          { name: "effective_start_date", type: "TIMESTAMP" },
          { name: "effective_end_date", type: "TIMESTAMP" },
          { name: "max_concurrent_runs", type: "INTEGER", default: "1" },
          { name: "is_active", type: "BOOLEAN", default: "true" },
          { name: "created_date", type: "TIMESTAMP" },
          { name: "created_by", type: "VARCHAR(128)" },
          { name: "updated_date", type: "TIMESTAMP" },
          { name: "updated_by", type: "VARCHAR(128)" },
        ],
      },
    },
  },
  "Dataset & Feature Layer": {
    color: "#CC6B4A",
    tables: {
      ml_dataset_registry: {
        description: "Versioned dataset catalog — ties training/evaluation data to model versions",
        columns: [
          { name: "dataset_id", type: "SERIAL", pk: true },
          { name: "project_id", type: "INTEGER", fk: "ml_project.project_id" },
          { name: "dataset_name", type: "VARCHAR(256)", nullable: false },
          { name: "dataset_code", type: "VARCHAR(128)", unique: true },
          { name: "dataset_type", type: "VARCHAR(64)", note: "training | validation | test | holdout | scoring | reference" },
          { name: "source_type", type: "VARCHAR(64)", note: "feed_contract | feature_store | custom_query | file_upload" },
          { name: "source_contract_id", type: "INTEGER", note: "FK to your existing contract_details" },
          { name: "source_query", type: "TEXT" },
          { name: "source_uri", type: "VARCHAR(1024)" },
          { name: "storage_format", type: "VARCHAR(32)", note: "parquet | delta | csv | orc" },
          { name: "storage_path", type: "VARCHAR(1024)" },
          { name: "version_number", type: "INTEGER", nullable: false },
          { name: "row_count", type: "BIGINT" },
          { name: "column_count", type: "INTEGER" },
          { name: "file_size_bytes", type: "BIGINT" },
          { name: "schema_hash", type: "VARCHAR(64)" },
          { name: "data_start_date", type: "DATE" },
          { name: "data_end_date", type: "DATE" },
          { name: "partition_columns", type: "VARCHAR(512)" },
          { name: "tags", type: "JSONB" },
          { name: "is_active", type: "BOOLEAN", default: "true" },
          { name: "created_date", type: "TIMESTAMP" },
          { name: "created_by", type: "VARCHAR(128)" },
          { name: "updated_date", type: "TIMESTAMP" },
          { name: "updated_by", type: "VARCHAR(128)" },
        ],
      },
      ml_feature_group: {
        description: "Feast-aligned feature group definition — logical grouping of features",
        columns: [
          { name: "feature_group_id", type: "SERIAL", pk: true },
          { name: "project_id", type: "INTEGER", fk: "ml_project.project_id" },
          { name: "feature_group_name", type: "VARCHAR(256)", nullable: false },
          { name: "feast_feature_view", type: "VARCHAR(256)", note: "Feast feature view name" },
          { name: "entity_name", type: "VARCHAR(128)", nullable: false, note: "Primary entity: customer_id, account_id" },
          { name: "source_type", type: "VARCHAR(64)", note: "batch | stream | on_demand" },
          { name: "source_table", type: "VARCHAR(512)" },
          { name: "source_connection_details", type: "JSONB" },
          { name: "ttl_seconds", type: "INTEGER" },
          { name: "refresh_frequency", type: "VARCHAR(32)", note: "daily | hourly | real_time" },
          { name: "description", type: "TEXT" },
          { name: "is_active", type: "BOOLEAN", default: "true" },
          { name: "created_date", type: "TIMESTAMP" },
          { name: "created_by", type: "VARCHAR(128)" },
          { name: "updated_date", type: "TIMESTAMP" },
          { name: "updated_by", type: "VARCHAR(128)" },
        ],
      },
      ml_feature_definition: {
        description: "Individual feature metadata within a feature group",
        columns: [
          { name: "feature_id", type: "SERIAL", pk: true },
          { name: "feature_group_id", type: "INTEGER", fk: "ml_feature_group.feature_group_id", nullable: false },
          { name: "feature_name", type: "VARCHAR(256)", nullable: false },
          { name: "feature_dtype", type: "VARCHAR(32)", nullable: false, note: "int64 | float64 | string | bool | datetime" },
          { name: "feature_description", type: "TEXT" },
          { name: "transformation_logic", type: "TEXT", note: "SQL or Python expression" },
          { name: "is_derived", type: "BOOLEAN", default: "false" },
          { name: "monotonicity_constraint", type: "VARCHAR(16)", note: "increasing | decreasing | none" },
          { name: "expected_range_min", type: "NUMERIC(18,6)" },
          { name: "expected_range_max", type: "NUMERIC(18,6)" },
          { name: "null_rate_threshold", type: "NUMERIC(5,4)" },
          { name: "psi_threshold", type: "NUMERIC(5,4)", note: "Population Stability Index threshold" },
          { name: "tags", type: "JSONB" },
          { name: "is_active", type: "BOOLEAN", default: "true" },
          { name: "created_date", type: "TIMESTAMP" },
          { name: "created_by", type: "VARCHAR(128)" },
          { name: "updated_date", type: "TIMESTAMP" },
          { name: "updated_by", type: "VARCHAR(128)" },
        ],
      },
    },
  },
  "Quality & Monitoring Layer": {
    color: "#CC4A5C",
    tables: {
      ml_quality_suite: {
        description: "Reusable quality check suite — maps to Great Expectations suites from your ingestion layer",
        columns: [
          { name: "suite_id", type: "SERIAL", pk: true },
          { name: "suite_name", type: "VARCHAR(256)", nullable: false, unique: true },
          { name: "suite_type", type: "VARCHAR(64)", nullable: false, note: "data_quality | model_performance | feature_drift | concept_drift | bias_fairness" },
          { name: "description", type: "TEXT" },
          { name: "ge_expectation_suite_name", type: "VARCHAR(256)", note: "Link to Great Expectations suite" },
          { name: "is_blocking", type: "BOOLEAN", default: "true", note: "If true, pipeline fails on quality breach" },
          { name: "notification_channel", type: "VARCHAR(128)" },
          { name: "is_active", type: "BOOLEAN", default: "true" },
          { name: "created_date", type: "TIMESTAMP" },
          { name: "created_by", type: "VARCHAR(128)" },
          { name: "updated_date", type: "TIMESTAMP" },
          { name: "updated_by", type: "VARCHAR(128)" },
        ],
      },
      ml_quality_check: {
        description: "Individual check definition within a suite",
        columns: [
          { name: "check_id", type: "SERIAL", pk: true },
          { name: "suite_id", type: "INTEGER", fk: "ml_quality_suite.suite_id", nullable: false },
          { name: "check_name", type: "VARCHAR(256)", nullable: false },
          { name: "check_type", type: "VARCHAR(64)", nullable: false, note: "ge_expectation | psi | csi | ks_test | auc_threshold | custom_sql | custom_python" },
          { name: "check_config", type: "JSONB", nullable: false, note: "Full check parameters" },
          { name: "severity", type: "VARCHAR(16)", nullable: false, note: "critical | warning | info" },
          { name: "threshold_value", type: "NUMERIC(18,6)" },
          { name: "threshold_operator", type: "VARCHAR(8)", note: "gt | gte | lt | lte | eq | between" },
          { name: "threshold_upper", type: "NUMERIC(18,6)" },
          { name: "is_active", type: "BOOLEAN", default: "true" },
          { name: "created_date", type: "TIMESTAMP" },
          { name: "created_by", type: "VARCHAR(128)" },
        ],
      },
      ml_quality_result: {
        description: "Execution results of quality checks — full audit trail",
        columns: [
          { name: "result_id", type: "SERIAL", pk: true },
          { name: "check_id", type: "INTEGER", fk: "ml_quality_check.check_id", nullable: false },
          { name: "execution_id", type: "INTEGER", fk: "ml_pipeline_execution.execution_id" },
          { name: "model_version_id", type: "INTEGER", fk: "ml_model_version.model_version_id" },
          { name: "dataset_id", type: "INTEGER", fk: "ml_dataset_registry.dataset_id" },
          { name: "check_status", type: "VARCHAR(16)", nullable: false, note: "passed | failed | warning | error" },
          { name: "actual_value", type: "NUMERIC(18,6)" },
          { name: "expected_value", type: "NUMERIC(18,6)" },
          { name: "deviation_pct", type: "NUMERIC(8,4)" },
          { name: "details", type: "JSONB", note: "Full GE validation result or custom details" },
          { name: "ge_run_id", type: "VARCHAR(256)" },
          { name: "remediation_action", type: "VARCHAR(64)", note: "none | pipeline_halted | alert_sent | auto_retrain_triggered" },
          { name: "evaluated_at", type: "TIMESTAMP", nullable: false },
          { name: "created_date", type: "TIMESTAMP" },
          { name: "created_by", type: "VARCHAR(128)" },
        ],
      },
      ml_drift_monitor: {
        description: "Continuous monitoring config for data & concept drift post-deployment",
        columns: [
          { name: "monitor_id", type: "SERIAL", pk: true },
          { name: "model_id", type: "INTEGER", fk: "ml_model_registry.model_id", nullable: false },
          { name: "monitor_name", type: "VARCHAR(256)" },
          { name: "monitor_type", type: "VARCHAR(64)", nullable: false, note: "data_drift | concept_drift | prediction_drift | feature_drift" },
          { name: "reference_dataset_id", type: "INTEGER", fk: "ml_dataset_registry.dataset_id" },
          { name: "reference_window", type: "VARCHAR(64)", note: "last_30d | training_baseline | custom" },
          { name: "detection_method", type: "VARCHAR(64)", note: "psi | ks_test | wasserstein | js_divergence | chi_squared" },
          { name: "threshold", type: "NUMERIC(8,4)" },
          { name: "evaluation_frequency", type: "VARCHAR(32)", note: "daily | weekly | on_scoring_run" },
          { name: "auto_retrain_on_breach", type: "BOOLEAN", default: "false" },
          { name: "alert_channel", type: "VARCHAR(128)" },
          { name: "is_active", type: "BOOLEAN", default: "true" },
          { name: "created_date", type: "TIMESTAMP" },
          { name: "created_by", type: "VARCHAR(128)" },
          { name: "updated_date", type: "TIMESTAMP" },
          { name: "updated_by", type: "VARCHAR(128)" },
        ],
      },
      ml_drift_result: {
        description: "Drift detection execution results — time-series of drift signals",
        columns: [
          { name: "drift_result_id", type: "SERIAL", pk: true },
          { name: "monitor_id", type: "INTEGER", fk: "ml_drift_monitor.monitor_id", nullable: false },
          { name: "model_version_id", type: "INTEGER", fk: "ml_model_version.model_version_id" },
          { name: "evaluation_date", type: "DATE", nullable: false },
          { name: "drift_score", type: "NUMERIC(10,6)" },
          { name: "is_drift_detected", type: "BOOLEAN", nullable: false },
          { name: "feature_drift_details", type: "JSONB", note: "{feature_name: {psi: 0.23, status: 'drifted'}}" },
          { name: "reference_stats", type: "JSONB" },
          { name: "current_stats", type: "JSONB" },
          { name: "action_taken", type: "VARCHAR(64)", note: "none | alert_sent | retrain_triggered | model_retired" },
          { name: "created_date", type: "TIMESTAMP" },
          { name: "created_by", type: "VARCHAR(128)" },
        ],
      },
    },
  },
  "Serving & Deployment": {
    color: "#3D7A8A",
    tables: {
      ml_serving_endpoint: {
        description: "Model serving endpoint configuration — batch scoring or real-time API",
        columns: [
          { name: "endpoint_id", type: "SERIAL", pk: true },
          { name: "model_id", type: "INTEGER", fk: "ml_model_registry.model_id", nullable: false },
          { name: "active_model_version_id", type: "INTEGER", fk: "ml_model_version.model_version_id" },
          { name: "endpoint_name", type: "VARCHAR(256)", nullable: false },
          { name: "endpoint_type", type: "VARCHAR(32)", nullable: false, note: "batch | rest_api | grpc | streaming" },
          { name: "endpoint_url", type: "VARCHAR(1024)" },
          { name: "route_name", type: "VARCHAR(256)", note: "OpenShift route" },
          { name: "namespace", type: "VARCHAR(128)" },
          { name: "compute_config_id", type: "INTEGER", fk: "ml_compute_config.compute_config_id" },
          { name: "scaling_policy", type: "JSONB", note: "{min_replicas: 2, max_replicas: 10, target_rps: 1000}" },
          { name: "traffic_split", type: "JSONB", note: "A/B or canary: {champion: 90, challenger: 10}" },
          { name: "health_check_path", type: "VARCHAR(256)" },
          { name: "sla_latency_p99_ms", type: "INTEGER" },
          { name: "is_active", type: "BOOLEAN", default: "true" },
          { name: "created_date", type: "TIMESTAMP" },
          { name: "created_by", type: "VARCHAR(128)" },
          { name: "updated_date", type: "TIMESTAMP" },
          { name: "updated_by", type: "VARCHAR(128)" },
        ],
      },
      ml_deployment_history: {
        description: "Immutable log of every deployment action for audit trail",
        columns: [
          { name: "deployment_id", type: "SERIAL", pk: true },
          { name: "endpoint_id", type: "INTEGER", fk: "ml_serving_endpoint.endpoint_id", nullable: false },
          { name: "model_version_id", type: "INTEGER", fk: "ml_model_version.model_version_id", nullable: false },
          { name: "action", type: "VARCHAR(32)", nullable: false, note: "deploy | rollback | scale | canary_promote | retire" },
          { name: "previous_model_version_id", type: "INTEGER", fk: "ml_model_version.model_version_id" },
          { name: "deployment_strategy", type: "VARCHAR(32)", note: "blue_green | canary | rolling | immediate" },
          { name: "deployment_status", type: "VARCHAR(32)", note: "pending | in_progress | completed | failed | rolled_back" },
          { name: "health_check_passed", type: "BOOLEAN" },
          { name: "smoke_test_passed", type: "BOOLEAN" },
          { name: "deployed_by", type: "VARCHAR(128)" },
          { name: "deployment_notes", type: "TEXT" },
          { name: "deployed_at", type: "TIMESTAMP" },
          { name: "created_date", type: "TIMESTAMP" },
          { name: "created_by", type: "VARCHAR(128)" },
        ],
      },
      ml_scoring_log: {
        description: "Batch scoring execution log — ties scoring runs to model versions and datasets",
        columns: [
          { name: "scoring_log_id", type: "SERIAL", pk: true },
          { name: "execution_id", type: "INTEGER", fk: "ml_pipeline_execution.execution_id" },
          { name: "endpoint_id", type: "INTEGER", fk: "ml_serving_endpoint.endpoint_id" },
          { name: "model_version_id", type: "INTEGER", fk: "ml_model_version.model_version_id", nullable: false },
          { name: "dataset_id", type: "INTEGER", fk: "ml_dataset_registry.dataset_id" },
          { name: "scoring_date", type: "DATE", nullable: false },
          { name: "records_scored", type: "BIGINT" },
          { name: "records_failed", type: "BIGINT" },
          { name: "output_uri", type: "VARCHAR(1024)" },
          { name: "avg_prediction", type: "NUMERIC(10,6)" },
          { name: "prediction_distribution", type: "JSONB", note: "Histogram bins for monitoring" },
          { name: "duration_seconds", type: "INTEGER" },
          { name: "created_date", type: "TIMESTAMP" },
          { name: "created_by", type: "VARCHAR(128)" },
        ],
      },
    },
  },
};

const AGENTS = [
  {
    id: "schema_design",
    name: "Schema Design Reviewer",
    icon: "🏗",
    role: "Validates normalization, naming conventions, FK integrity, and alignment with the existing ingestion schema patterns",
    prompt: `You are a senior database architect reviewing a PostgreSQL schema for an ML metadata platform. The schema must align with existing ingestion pipeline conventions (audit columns: created_date/created_by/updated_date/updated_by, is_active flags, SERIAL PKs, JSONB for flexible config).

Evaluate:
1. Normalization — any 3NF violations, redundant columns, or missing junction tables?
2. Naming consistency — do table/column names follow snake_case, are they self-documenting?
3. FK integrity — are all relationships properly defined? Any orphan risks?
4. Data types — appropriate use of SERIAL, UUID, JSONB, NUMERIC precision?
5. Index strategy — what indexes would you recommend?
6. Missing tables — any metadata gaps?

Respond ONLY in this JSON format (no markdown, no backticks):
{"score": <number 1-10>, "verdict": "<PASS|WARN|FAIL>", "strengths": ["..."], "issues": ["..."], "recommendations": ["..."]}`,
  },
  {
    id: "mlops",
    name: "MLOps Engineer",
    icon: "⚙",
    role: "Validates ML lifecycle coverage — experiment tracking, model registry, deployment, A/B, rollback, retraining triggers",
    prompt: `You are a senior MLOps engineer who has built ML platforms at scale (100+ models in production). Review this ML metadata schema for production readiness.

Evaluate:
1. Experiment tracking — does the run → experiment → project hierarchy support MLflow integration?
2. Model lifecycle — development → staging → champion → challenger → archived flow?
3. Deployment patterns — batch scoring, real-time serving, A/B testing, canary, rollback?
4. Retraining triggers — drift detection → auto-retrain → validation → promotion pipeline?
5. Lineage — can you trace from a prediction back to training data, features, code version?
6. Compute management — Spark, K8s, GPU allocation?

Respond ONLY in this JSON format (no markdown, no backticks):
{"score": <number 1-10>, "verdict": "<PASS|WARN|FAIL>", "strengths": ["..."], "issues": ["..."], "recommendations": ["..."]}`,
  },
  {
    id: "data_quality",
    name: "Data Quality & GE Specialist",
    icon: "🔍",
    role: "Validates quality check coverage, GE integration, drift monitoring, PSI/CSI/KS tracking",
    prompt: `You are a senior data quality engineer specializing in Great Expectations (GE) and ML model monitoring. Review this schema's quality and monitoring layer.

Evaluate:
1. GE integration — does the suite/check/result pattern map cleanly to GE's ExpectationSuite → ValidationResult?
2. Drift monitoring — PSI, CSI, KS test support for both features and predictions?
3. Quality gates — blocking vs warning checks, severity levels, remediation actions?
4. Audit trail — can regulators trace every quality check result back to the model version and dataset?
5. Alerting — notification channels, auto-retrain triggers on drift breach?
6. Credit risk specifics — SR11-7 model risk tiers, CECL/CCAR compliance fields?

Respond ONLY in this JSON format (no markdown, no backticks):
{"score": <number 1-10>, "verdict": "<PASS|WARN|FAIL>", "strengths": ["..."], "issues": ["..."], "recommendations": ["..."]}`,
  },
  {
    id: "security_governance",
    name: "Security & Governance Auditor",
    icon: "🛡",
    role: "Validates RBAC, audit logging, data lineage, regulatory compliance (SR11-7, CECL, CCAR)",
    prompt: `You are a model governance and security auditor at a financial institution. Review this ML metadata schema for compliance and security.

Evaluate:
1. Audit trail — created_by/updated_by on every table, deployment history immutability?
2. Access control readiness — are there ownership fields for RBAC integration?
3. Model approval workflow — approval_status, approved_by, approval_notes on model versions?
4. Regulatory fields — risk_tier, regulatory_scope (SR11-7, CECL, CCAR)?
5. Data lineage — full traceability from scoring output → model version → training data → source feed?
6. Artifact integrity — checksum_sha256 on model artifacts, schema_hash on datasets?

Respond ONLY in this JSON format (no markdown, no backticks):
{"score": <number 1-10>, "verdict": "<PASS|WARN|FAIL>", "strengths": ["..."], "issues": ["..."], "recommendations": ["..."]}`,
  },
  {
    id: "feast_integration",
    name: "Feast / Feature Store Architect",
    icon: "🍽",
    role: "Validates Feast alignment, feature versioning, online/offline serving patterns, entity management",
    prompt: `You are a feature store architect who has deployed Feast at enterprise scale. Review this schema's feature layer for Feast compatibility.

Evaluate:
1. Feast alignment — does ml_feature_group map to FeatureView? Is entity_name consistent with Feast Entity?
2. Feature metadata — dtype, transformation logic, descriptions adequate for a feature catalog?
3. Online/offline patterns — TTL, refresh frequency, source types (batch/stream/on_demand)?
4. Feature quality — null_rate_threshold, expected_range, PSI threshold per feature?
5. Versioning — how are feature definition changes tracked over time?
6. Feature lineage — can you trace which features went into which model version?

Respond ONLY in this JSON format (no markdown, no backticks):
{"score": <number 1-10>, "verdict": "<PASS|WARN|FAIL>", "strengths": ["..."], "issues": ["..."], "recommendations": ["..."]}`,
  },
];

const schemaText = Object.entries(SCHEMA)
  .map(([layer, { tables }]) =>
    Object.entries(tables)
      .map(
        ([tbl, { description, columns }]) =>
          `TABLE: ${tbl} (${description})\nColumns: ${columns.map((c) => `${c.name} ${c.type}${c.pk ? " PK" : ""}${c.fk ? ` FK→${c.fk}` : ""}${c.note ? ` -- ${c.note}` : ""}`).join(", ")}`
      )
      .join("\n")
  )
  .join("\n\n");

function StatusBadge({ status }) {
  const styles = {
    PASS: { bg: "#1a3a2a", color: "#5BCC7E", border: "#2a5a3a" },
    WARN: { bg: "#3a3520", color: "#E8BF44", border: "#5a5530" },
    FAIL: { bg: "#3a1a20", color: "#CC4A5C", border: "#5a2a30" },
    pending: { bg: "#1a1a2a", color: "#6a6a8a", border: "#2a2a4a" },
  };
  const s = styles[status] || styles.pending;
  return (
    <span style={{ background: s.bg, color: s.color, border: `1px solid ${s.border}`, padding: "2px 10px", borderRadius: "4px", fontSize: "11px", fontWeight: 700, letterSpacing: "0.5px", fontFamily: "'JetBrains Mono', monospace" }}>
      {status}
    </span>
  );
}

function ScoreRing({ score, size = 48 }) {
  const r = (size - 6) / 2;
  const c = 2 * Math.PI * r;
  const pct = score / 10;
  const color = score >= 8 ? "#5BCC7E" : score >= 6 ? "#E8BF44" : "#CC4A5C";
  return (
    <svg width={size} height={size} style={{ display: "block" }}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#1a1a2a" strokeWidth="3" />
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth="3" strokeDasharray={`${pct * c} ${c}`} strokeLinecap="round" transform={`rotate(-90 ${size / 2} ${size / 2})`} style={{ transition: "stroke-dasharray 0.8s ease" }} />
      <text x={size / 2} y={size / 2 + 1} textAnchor="middle" dominantBaseline="central" fill={color} fontSize="14" fontWeight="800" fontFamily="'JetBrains Mono', monospace">
        {score}
      </text>
    </svg>
  );
}

function TableCard({ name, table, color }) {
  const [open, setOpen] = useState(false);
  return (
    <div style={{ background: "#0d0d14", border: `1px solid ${color}33`, borderRadius: "6px", marginBottom: "8px", overflow: "hidden" }}>
      <div onClick={() => setOpen(!open)} style={{ padding: "10px 14px", cursor: "pointer", display: "flex", alignItems: "center", gap: "10px", borderLeft: `3px solid ${color}` }}>
        <span style={{ color, fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, fontSize: "13px" }}>{name}</span>
        <span style={{ color: "#6a6a8a", fontSize: "12px", flex: 1 }}>{table.description}</span>
        <span style={{ color: "#4a4a6a", fontSize: "12px" }}>{table.columns.length} cols</span>
        <span style={{ color: "#4a4a6a", fontSize: "16px", transform: open ? "rotate(90deg)" : "none", transition: "transform 0.2s" }}>›</span>
      </div>
      {open && (
        <div style={{ padding: "0 14px 12px 17px", borderLeft: `3px solid ${color}` }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "11px" }}>
            <thead>
              <tr style={{ color: "#5a5a7a" }}>
                <th style={{ textAlign: "left", padding: "4px 8px", borderBottom: "1px solid #1a1a2a" }}>Column</th>
                <th style={{ textAlign: "left", padding: "4px 8px", borderBottom: "1px solid #1a1a2a" }}>Type</th>
                <th style={{ textAlign: "left", padding: "4px 8px", borderBottom: "1px solid #1a1a2a" }}>Constraints</th>
                <th style={{ textAlign: "left", padding: "4px 8px", borderBottom: "1px solid #1a1a2a" }}>Notes</th>
              </tr>
            </thead>
            <tbody>
              {table.columns.map((col) => (
                <tr key={col.name} style={{ borderBottom: "1px solid #0f0f1a" }}>
                  <td style={{ padding: "3px 8px", color: col.pk ? color : col.fk ? "#7aa8cc" : "#c0c0d0", fontFamily: "'JetBrains Mono', monospace", fontWeight: col.pk ? 700 : 400 }}>
                    {col.pk && <span style={{ color, marginRight: 4, fontSize: 9 }}>PK</span>}
                    {col.fk && <span style={{ color: "#7aa8cc", marginRight: 4, fontSize: 9 }}>FK</span>}
                    {col.name}
                  </td>
                  <td style={{ padding: "3px 8px", color: "#8a8aaa", fontFamily: "'JetBrains Mono', monospace" }}>{col.type}</td>
                  <td style={{ padding: "3px 8px", color: "#6a6a8a" }}>
                    {[col.nullable === false && "NOT NULL", col.unique && "UNIQUE", col.default && `DEFAULT ${col.default}`].filter(Boolean).join(", ") || "—"}
                  </td>
                  <td style={{ padding: "3px 8px", color: "#5a5a7a", maxWidth: 260, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{col.note || "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function AgentCard({ agent, result, running }) {
  const [expanded, setExpanded] = useState(false);
  const data = result?.data;
  return (
    <div style={{ background: "#0d0d14", border: "1px solid #1a1a2a", borderRadius: "8px", overflow: "hidden", transition: "border-color 0.3s", borderColor: data ? (data.verdict === "PASS" ? "#2a5a3a" : data.verdict === "WARN" ? "#5a5530" : "#5a2a30") : "#1a1a2a" }}>
      <div onClick={() => data && setExpanded(!expanded)} style={{ padding: "14px 16px", cursor: data ? "pointer" : "default", display: "flex", alignItems: "center", gap: "12px" }}>
        <span style={{ fontSize: "22px", filter: running ? "grayscale(1)" : "none" }}>{agent.icon}</span>
        <div style={{ flex: 1 }}>
          <div style={{ color: "#e0e0ea", fontWeight: 700, fontSize: "13px", fontFamily: "'Space Mono', monospace" }}>{agent.name}</div>
          <div style={{ color: "#5a5a7a", fontSize: "11px", marginTop: 2 }}>{agent.role}</div>
        </div>
        {running && (
          <div style={{ display: "flex", gap: 4, alignItems: "center" }}>
            {[0, 1, 2].map((i) => (
              <div key={i} style={{ width: 6, height: 6, borderRadius: "50%", background: "#4a8fcc", animation: `pulse 1s ${i * 0.2}s infinite` }} />
            ))}
          </div>
        )}
        {data && <ScoreRing score={data.score} />}
        {data && <StatusBadge status={data.verdict} />}
        {!running && !data && <StatusBadge status="pending" />}
      </div>
      {expanded && data && (
        <div style={{ padding: "0 16px 16px 54px", display: "flex", flexDirection: "column", gap: "12px" }}>
          {data.strengths?.length > 0 && (
            <div>
              <div style={{ color: "#5BCC7E", fontSize: "10px", fontWeight: 700, letterSpacing: "1px", marginBottom: 6, fontFamily: "'JetBrains Mono', monospace" }}>STRENGTHS</div>
              {data.strengths.map((s, i) => (
                <div key={i} style={{ color: "#a0a0b0", fontSize: "12px", padding: "3px 0", display: "flex", gap: 8 }}>
                  <span style={{ color: "#5BCC7E" }}>+</span> {s}
                </div>
              ))}
            </div>
          )}
          {data.issues?.length > 0 && (
            <div>
              <div style={{ color: "#CC4A5C", fontSize: "10px", fontWeight: 700, letterSpacing: "1px", marginBottom: 6, fontFamily: "'JetBrains Mono', monospace" }}>ISSUES</div>
              {data.issues.map((s, i) => (
                <div key={i} style={{ color: "#a0a0b0", fontSize: "12px", padding: "3px 0", display: "flex", gap: 8 }}>
                  <span style={{ color: "#CC4A5C" }}>!</span> {s}
                </div>
              ))}
            </div>
          )}
          {data.recommendations?.length > 0 && (
            <div>
              <div style={{ color: "#4A8FCC", fontSize: "10px", fontWeight: 700, letterSpacing: "1px", marginBottom: 6, fontFamily: "'JetBrains Mono', monospace" }}>RECOMMENDATIONS</div>
              {data.recommendations.map((s, i) => (
                <div key={i} style={{ color: "#a0a0b0", fontSize: "12px", padding: "3px 0", display: "flex", gap: 8 }}>
                  <span style={{ color: "#4A8FCC" }}>→</span> {s}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default function App() {
  const [tab, setTab] = useState("schema");
  const [results, setResults] = useState({});
  const [running, setRunning] = useState({});
  const [validationStarted, setValidationStarted] = useState(false);
  const abortRef = useRef(null);

  const totalTables = Object.values(SCHEMA).reduce((sum, l) => sum + Object.keys(l.tables).length, 0);
  const totalCols = Object.values(SCHEMA).reduce((sum, l) => sum + Object.values(l.tables).reduce((s2, t) => s2 + t.columns.length, 0), 0);

  const runAgent = useCallback(async (agent) => {
    setRunning((p) => ({ ...p, [agent.id]: true }));
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          messages: [{ role: "user", content: `${agent.prompt}\n\nHere is the full schema:\n\n${schemaText}` }],
        }),
      });
      const data = await res.json();
      const text = data.content?.map((b) => b.text || "").join("") || "";
      const clean = text.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(clean);
      setResults((p) => ({ ...p, [agent.id]: { data: parsed } }));
    } catch (err) {
      setResults((p) => ({
        ...p,
        [agent.id]: {
          data: { score: 0, verdict: "FAIL", strengths: [], issues: [`Agent error: ${err.message}`], recommendations: ["Retry validation"] },
        },
      }));
    } finally {
      setRunning((p) => ({ ...p, [agent.id]: false }));
    }
  }, []);

  const runAllAgents = useCallback(async () => {
    setValidationStarted(true);
    setResults({});
    for (const agent of AGENTS) {
      await runAgent(agent);
    }
  }, [runAgent]);

  const completedAgents = Object.keys(results).length;
  const avgScore = completedAgents > 0 ? (Object.values(results).reduce((s, r) => s + (r.data?.score || 0), 0) / completedAgents).toFixed(1) : "—";

  return (
    <div style={{ minHeight: "100vh", background: "#08080e", color: "#e0e0ea", fontFamily: "'DM Sans', 'Segoe UI', sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&family=JetBrains+Mono:wght@400;700&family=Space+Mono:wght@400;700&display=swap');
        @keyframes pulse { 0%,100% { opacity: 0.3; transform: scale(0.8); } 50% { opacity: 1; transform: scale(1.2); } }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: #0d0d14; }
        ::-webkit-scrollbar-thumb { background: #2a2a4a; border-radius: 3px; }
      `}</style>

      {/* Header */}
      <div style={{ padding: "28px 32px 20px", borderBottom: "1px solid #1a1a2a" }}>
        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
          <div>
            <h1 style={{ margin: 0, fontSize: "20px", fontWeight: 700, letterSpacing: "-0.5px", fontFamily: "'Space Mono', monospace" }}>
              <span style={{ color: "#4A8FCC" }}>ml_</span>metadata_architecture
            </h1>
            <p style={{ margin: "6px 0 0", color: "#5a5a7a", fontSize: "13px" }}>
              PostgreSQL schema for ML/Analytics workload orchestration, model registry & quality monitoring
            </p>
          </div>
          <div style={{ display: "flex", gap: 20, alignItems: "center" }}>
            <div style={{ textAlign: "center" }}>
              <div style={{ color: "#E8BF44", fontSize: "22px", fontWeight: 800, fontFamily: "'JetBrains Mono', monospace" }}>{totalTables}</div>
              <div style={{ color: "#5a5a7a", fontSize: "10px", letterSpacing: "1px" }}>TABLES</div>
            </div>
            <div style={{ textAlign: "center" }}>
              <div style={{ color: "#5BA37E", fontSize: "22px", fontWeight: 800, fontFamily: "'JetBrains Mono', monospace" }}>{totalCols}</div>
              <div style={{ color: "#5a5a7a", fontSize: "10px", letterSpacing: "1px" }}>COLUMNS</div>
            </div>
            <div style={{ textAlign: "center" }}>
              <div style={{ color: "#4A8FCC", fontSize: "22px", fontWeight: 800, fontFamily: "'JetBrains Mono', monospace" }}>6</div>
              <div style={{ color: "#5a5a7a", fontSize: "10px", letterSpacing: "1px" }}>LAYERS</div>
            </div>
          </div>
        </div>
        <div style={{ display: "flex", gap: 0, marginTop: 20 }}>
          {["schema", "validation"].map((t) => (
            <button key={t} onClick={() => setTab(t)} style={{ padding: "8px 20px", background: tab === t ? "#1a1a2a" : "transparent", border: "1px solid #1a1a2a", borderBottom: tab === t ? "1px solid #1a1a2a" : "1px solid #2a2a4a", color: tab === t ? "#e0e0ea" : "#5a5a7a", cursor: "pointer", fontSize: "12px", fontWeight: 600, fontFamily: "'JetBrains Mono', monospace", letterSpacing: "0.5px", borderRadius: t === "schema" ? "6px 0 0 0" : "0 6px 0 0" }}>
              {t === "schema" ? "SCHEMA EXPLORER" : "AGENT VALIDATION"}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div style={{ padding: "24px 32px" }}>
        {tab === "schema" && (
          <div style={{ animation: "fadeIn 0.3s ease" }}>
            {Object.entries(SCHEMA).map(([layerName, { color, tables }]) => (
              <div key={layerName} style={{ marginBottom: 24 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
                  <div style={{ width: 12, height: 12, borderRadius: "2px", background: color }} />
                  <h2 style={{ margin: 0, fontSize: "14px", fontWeight: 700, color: color, fontFamily: "'Space Mono', monospace", letterSpacing: "-0.3px" }}>{layerName}</h2>
                  <span style={{ color: "#4a4a6a", fontSize: "11px" }}>({Object.keys(tables).length} tables)</span>
                </div>
                {Object.entries(tables).map(([tblName, tbl]) => (
                  <TableCard key={tblName} name={tblName} table={tbl} color={color} />
                ))}
              </div>
            ))}
          </div>
        )}

        {tab === "validation" && (
          <div style={{ animation: "fadeIn 0.3s ease" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
              <div>
                <h2 style={{ margin: 0, fontSize: "16px", fontWeight: 700, fontFamily: "'Space Mono', monospace" }}>Multi-Agent Validation</h2>
                <p style={{ margin: "4px 0 0", color: "#5a5a7a", fontSize: "12px" }}>5 specialized agents review the schema across different dimensions</p>
              </div>
              <div style={{ display: "flex", gap: 16, alignItems: "center" }}>
                {validationStarted && completedAgents > 0 && (
                  <div style={{ textAlign: "center" }}>
                    <div style={{ color: "#e0e0ea", fontSize: "18px", fontWeight: 800, fontFamily: "'JetBrains Mono', monospace" }}>{avgScore}<span style={{ fontSize: 11, color: "#5a5a7a" }}>/10</span></div>
                    <div style={{ color: "#5a5a7a", fontSize: "10px", letterSpacing: "1px" }}>AVG SCORE</div>
                  </div>
                )}
                <button onClick={runAllAgents} disabled={Object.values(running).some(Boolean)} style={{ padding: "10px 24px", background: Object.values(running).some(Boolean) ? "#1a1a2a" : "linear-gradient(135deg, #4A8FCC, #5BA37E)", border: "none", borderRadius: "6px", color: "#fff", cursor: Object.values(running).some(Boolean) ? "not-allowed" : "pointer", fontSize: "12px", fontWeight: 700, fontFamily: "'JetBrains Mono', monospace", letterSpacing: "0.5px" }}>
                  {Object.values(running).some(Boolean) ? `VALIDATING ${completedAgents}/${AGENTS.length}...` : validationStarted ? "RE-VALIDATE" : "RUN ALL AGENTS"}
                </button>
              </div>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {AGENTS.map((agent) => (
                <AgentCard key={agent.id} agent={agent} result={results[agent.id]} running={running[agent.id]} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
