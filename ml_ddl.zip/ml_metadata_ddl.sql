-- ============================================================================
-- ML/ANALYTICS METADATA ARCHITECTURE — PostgreSQL DDL
-- ============================================================================
-- Designed to complement existing data ingestion pipeline (contract_details,
-- feed_group_details, schema_details, etc.)
-- Conventions: snake_case, SERIAL PKs, audit columns, is_active flags, JSONB
-- ============================================================================

-- Create schema
CREATE SCHEMA IF NOT EXISTS ml_meta;
SET search_path TO ml_meta, public;

-- ============================================================================
-- LAYER 1: EXPERIMENT & PROJECT
-- ============================================================================

CREATE TABLE ml_project (
    project_id          SERIAL PRIMARY KEY,
    project_name        VARCHAR(256) NOT NULL,
    project_code        VARCHAR(64) NOT NULL UNIQUE,
    description         TEXT,
    business_unit       VARCHAR(128),
    department_name     VARCHAR(128),
    project_owner       VARCHAR(256),
    email_id            VARCHAR(256),
    project_type        VARCHAR(64)
        CHECK (project_type IN ('classification','regression','clustering',
               'forecasting','anomaly_detection','recommender','nlp','custom')),
    risk_tier           VARCHAR(32)
        CHECK (risk_tier IN ('critical','high','medium','low')),
    regulatory_scope    VARCHAR(128),                -- CECL, CCAR, IFRS9, Basel
    is_active           BOOLEAN DEFAULT TRUE,
    created_date        TIMESTAMP DEFAULT NOW(),
    created_by          VARCHAR(128),
    updated_date        TIMESTAMP DEFAULT NOW(),
    updated_by          VARCHAR(128)
);

CREATE INDEX idx_ml_project_code ON ml_project(project_code);
CREATE INDEX idx_ml_project_active ON ml_project(is_active) WHERE is_active = TRUE;

-- ---------------------------------------------------------------------------

CREATE TABLE ml_experiment (
    experiment_id       SERIAL PRIMARY KEY,
    project_id          INTEGER NOT NULL REFERENCES ml_project(project_id),
    experiment_name     VARCHAR(256) NOT NULL,
    experiment_code     VARCHAR(128) UNIQUE,
    hypothesis          TEXT,
    objective_metric    VARCHAR(128),                -- AUC, RMSE, Gini, KS
    objective_direction VARCHAR(16)
        CHECK (objective_direction IN ('minimize','maximize')),
    baseline_metric_value NUMERIC(18,6),
    tags                JSONB DEFAULT '{}',
    is_active           BOOLEAN DEFAULT TRUE,
    created_date        TIMESTAMP DEFAULT NOW(),
    created_by          VARCHAR(128),
    updated_date        TIMESTAMP DEFAULT NOW(),
    updated_by          VARCHAR(128)
);

CREATE INDEX idx_ml_experiment_project ON ml_experiment(project_id);
CREATE INDEX idx_ml_experiment_tags ON ml_experiment USING GIN(tags);

-- ---------------------------------------------------------------------------

CREATE TABLE ml_experiment_run (
    run_id              SERIAL PRIMARY KEY,
    experiment_id       INTEGER NOT NULL REFERENCES ml_experiment(experiment_id),
    run_uuid            UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(),
    parent_run_id       INTEGER REFERENCES ml_experiment_run(run_id),
    run_name            VARCHAR(256),
    run_status          VARCHAR(32) NOT NULL
        CHECK (run_status IN ('queued','running','completed','failed','killed','timeout')),
    trigger_type        VARCHAR(32)
        CHECK (trigger_type IN ('manual','scheduled','ci_cd','drift_alert','retrain')),
    git_commit_sha      VARCHAR(64),
    git_branch          VARCHAR(256),
    git_repo_url        VARCHAR(512),
    docker_image_uri    VARCHAR(512),
    entry_point         VARCHAR(512),
    hyperparameters     JSONB DEFAULT '{}',
    metrics             JSONB DEFAULT '{}',          -- {auc: 0.87, ks: 0.45, gini: 0.74}
    start_time          TIMESTAMP,
    end_time            TIMESTAMP,
    duration_seconds    INTEGER GENERATED ALWAYS AS
                        (EXTRACT(EPOCH FROM (end_time - start_time))::INTEGER) STORED,
    error_message       TEXT,
    error_traceback     TEXT,
    tags                JSONB DEFAULT '{}',
    created_date        TIMESTAMP DEFAULT NOW(),
    created_by          VARCHAR(128),
    updated_date        TIMESTAMP DEFAULT NOW(),
    updated_by          VARCHAR(128)
);

CREATE INDEX idx_ml_run_experiment ON ml_experiment_run(experiment_id);
CREATE INDEX idx_ml_run_status ON ml_experiment_run(run_status);
CREATE INDEX idx_ml_run_uuid ON ml_experiment_run(run_uuid);
CREATE INDEX idx_ml_run_metrics ON ml_experiment_run USING GIN(metrics);
CREATE INDEX idx_ml_run_start ON ml_experiment_run(start_time DESC);

-- ============================================================================
-- LAYER 2: DATASET & FEATURE
-- ============================================================================

CREATE TABLE ml_dataset_registry (
    dataset_id          SERIAL PRIMARY KEY,
    project_id          INTEGER REFERENCES ml_project(project_id),
    dataset_name        VARCHAR(256) NOT NULL,
    dataset_code        VARCHAR(128) UNIQUE,
    dataset_type        VARCHAR(64)
        CHECK (dataset_type IN ('training','validation','test','holdout','scoring','reference')),
    source_type         VARCHAR(64)
        CHECK (source_type IN ('feed_contract','feature_store','custom_query','file_upload')),
    source_contract_id  INTEGER,                     -- FK to ingestion contract_details
    source_query        TEXT,
    source_uri          VARCHAR(1024),
    storage_format      VARCHAR(32)
        CHECK (storage_format IN ('parquet','delta','csv','orc','avro')),
    storage_path        VARCHAR(1024),
    version_number      INTEGER NOT NULL DEFAULT 1,
    row_count           BIGINT,
    column_count        INTEGER,
    file_size_bytes     BIGINT,
    schema_hash         VARCHAR(64),
    data_start_date     DATE,
    data_end_date       DATE,
    partition_columns   VARCHAR(512),
    tags                JSONB DEFAULT '{}',
    is_active           BOOLEAN DEFAULT TRUE,
    created_date        TIMESTAMP DEFAULT NOW(),
    created_by          VARCHAR(128),
    updated_date        TIMESTAMP DEFAULT NOW(),
    updated_by          VARCHAR(128),

    UNIQUE (dataset_code, version_number)
);

CREATE INDEX idx_ml_dataset_project ON ml_dataset_registry(project_id);
CREATE INDEX idx_ml_dataset_type ON ml_dataset_registry(dataset_type);

-- ---------------------------------------------------------------------------

CREATE TABLE ml_feature_group (
    feature_group_id    SERIAL PRIMARY KEY,
    project_id          INTEGER REFERENCES ml_project(project_id),
    feature_group_name  VARCHAR(256) NOT NULL,
    feast_feature_view  VARCHAR(256),                -- Feast FeatureView name
    entity_name         VARCHAR(128) NOT NULL,       -- customer_id, account_id
    source_type         VARCHAR(64)
        CHECK (source_type IN ('batch','stream','on_demand')),
    source_table        VARCHAR(512),
    source_connection_details JSONB,
    ttl_seconds         INTEGER,
    refresh_frequency   VARCHAR(32)
        CHECK (refresh_frequency IN ('daily','hourly','real_time','weekly','monthly')),
    description         TEXT,
    is_active           BOOLEAN DEFAULT TRUE,
    created_date        TIMESTAMP DEFAULT NOW(),
    created_by          VARCHAR(128),
    updated_date        TIMESTAMP DEFAULT NOW(),
    updated_by          VARCHAR(128)
);

CREATE INDEX idx_ml_fg_project ON ml_feature_group(project_id);
CREATE INDEX idx_ml_fg_feast ON ml_feature_group(feast_feature_view);

-- ---------------------------------------------------------------------------

CREATE TABLE ml_feature_definition (
    feature_id          SERIAL PRIMARY KEY,
    feature_group_id    INTEGER NOT NULL REFERENCES ml_feature_group(feature_group_id),
    feature_name        VARCHAR(256) NOT NULL,
    feature_dtype       VARCHAR(32) NOT NULL
        CHECK (feature_dtype IN ('int64','float64','string','bool','datetime','array','struct')),
    feature_description TEXT,
    transformation_logic TEXT,                       -- SQL or Python expression
    is_derived          BOOLEAN DEFAULT FALSE,
    monotonicity_constraint VARCHAR(16)
        CHECK (monotonicity_constraint IN ('increasing','decreasing','none')),
    expected_range_min  NUMERIC(18,6),
    expected_range_max  NUMERIC(18,6),
    null_rate_threshold NUMERIC(5,4),
    psi_threshold       NUMERIC(5,4),                -- Population Stability Index
    tags                JSONB DEFAULT '{}',
    is_active           BOOLEAN DEFAULT TRUE,
    created_date        TIMESTAMP DEFAULT NOW(),
    created_by          VARCHAR(128),
    updated_date        TIMESTAMP DEFAULT NOW(),
    updated_by          VARCHAR(128),

    UNIQUE (feature_group_id, feature_name)
);

CREATE INDEX idx_ml_feat_group ON ml_feature_definition(feature_group_id);

-- ============================================================================
-- LAYER 3: MODEL REGISTRY & ARTIFACTS
-- ============================================================================

CREATE TABLE ml_model_registry (
    model_id            SERIAL PRIMARY KEY,
    project_id          INTEGER NOT NULL REFERENCES ml_project(project_id),
    model_name          VARCHAR(256) NOT NULL,
    model_code          VARCHAR(128) UNIQUE,
    model_type          VARCHAR(64)
        CHECK (model_type IN ('logistic_regression','xgboost','lightgbm','random_forest',
               'neural_net','ensemble','spark_ml','custom')),
    framework           VARCHAR(64)
        CHECK (framework IN ('sklearn','spark_ml','pytorch','tensorflow','xgboost',
               'lightgbm','catboost','h2o','custom')),
    description         TEXT,
    model_owner         VARCHAR(256),
    model_risk_rating   VARCHAR(32)
        CHECK (model_risk_rating IN ('critical','high','medium','low')),
    is_active           BOOLEAN DEFAULT TRUE,
    created_date        TIMESTAMP DEFAULT NOW(),
    created_by          VARCHAR(128),
    updated_date        TIMESTAMP DEFAULT NOW(),
    updated_by          VARCHAR(128)
);

CREATE INDEX idx_ml_model_project ON ml_model_registry(project_id);
CREATE INDEX idx_ml_model_code ON ml_model_registry(model_code);

-- ---------------------------------------------------------------------------

CREATE TABLE ml_model_version (
    model_version_id    SERIAL PRIMARY KEY,
    model_id            INTEGER NOT NULL REFERENCES ml_model_registry(model_id),
    run_id              INTEGER NOT NULL REFERENCES ml_experiment_run(run_id),
    version_number      INTEGER NOT NULL,
    stage               VARCHAR(32) NOT NULL
        CHECK (stage IN ('development','staging','champion','challenger','archived','retired')),
    promoted_date       TIMESTAMP,
    promoted_by         VARCHAR(128),
    approval_status     VARCHAR(32) DEFAULT 'pending'
        CHECK (approval_status IN ('pending','approved','rejected')),
    approved_by         VARCHAR(128),
    approval_date       TIMESTAMP,
    approval_notes      TEXT,
    model_signature     JSONB,                       -- Input/output schema
    feature_importance  JSONB,
    training_dataset_id INTEGER REFERENCES ml_dataset_registry(dataset_id),
    validation_dataset_id INTEGER REFERENCES ml_dataset_registry(dataset_id),
    metrics_snapshot    JSONB,
    is_active           BOOLEAN DEFAULT TRUE,
    created_date        TIMESTAMP DEFAULT NOW(),
    created_by          VARCHAR(128),
    updated_date        TIMESTAMP DEFAULT NOW(),
    updated_by          VARCHAR(128),

    UNIQUE (model_id, version_number)
);

CREATE INDEX idx_ml_mv_model ON ml_model_version(model_id);
CREATE INDEX idx_ml_mv_run ON ml_model_version(run_id);
CREATE INDEX idx_ml_mv_stage ON ml_model_version(stage);
CREATE INDEX idx_ml_mv_approval ON ml_model_version(approval_status);

-- ---------------------------------------------------------------------------

CREATE TABLE ml_model_artifact (
    artifact_id         SERIAL PRIMARY KEY,
    model_version_id    INTEGER NOT NULL REFERENCES ml_model_version(model_version_id),
    artifact_type       VARCHAR(64) NOT NULL
        CHECK (artifact_type IN ('model_binary','onnx','pmml','feature_encoder',
               'scaler','tokenizer','config','explainer','shap_values')),
    artifact_uri        VARCHAR(1024) NOT NULL,       -- s3:// or cdfs:// path
    artifact_format     VARCHAR(64)
        CHECK (artifact_format IN ('pickle','joblib','onnx','pmml','safetensors',
               'h5','pt','savedmodel','mlmodel')),
    file_size_bytes     BIGINT,
    checksum_sha256     VARCHAR(64),
    is_active           BOOLEAN DEFAULT TRUE,
    created_date        TIMESTAMP DEFAULT NOW(),
    created_by          VARCHAR(128)
);

CREATE INDEX idx_ml_artifact_mv ON ml_model_artifact(model_version_id);

-- ============================================================================
-- LAYER 4: COMPUTE & INFRASTRUCTURE
-- ============================================================================

CREATE TABLE ml_compute_config (
    compute_config_id   SERIAL PRIMARY KEY,
    config_name         VARCHAR(256) NOT NULL,
    config_code         VARCHAR(128) UNIQUE,
    compute_type        VARCHAR(64) NOT NULL
        CHECK (compute_type IN ('spark','kubernetes','single_node','gpu_cluster','serverless')),
    cluster_namespace   VARCHAR(128),                -- OpenShift/K8s namespace
    exec_instances      INTEGER,                     -- Spark executors or pod replicas
    exec_cores          INTEGER,
    exec_mem            VARCHAR(32),                 -- e.g., 8g, 16g
    driver_cores        INTEGER,
    driver_mem          VARCHAR(32),
    pyspark_mem         VARCHAR(32),                 -- spark.executor.pyspark.memory
    gpu_type            VARCHAR(64)
        CHECK (gpu_type IN ('nvidia-t4','nvidia-a100','nvidia-v100','nvidia-h100','none')),
    gpu_count           INTEGER DEFAULT 0,
    spark_conf_overrides JSONB DEFAULT '{}',
    env_variables       JSONB DEFAULT '{}',
    docker_image_uri    VARCHAR(512),
    resource_quota_cpu  VARCHAR(32),
    resource_quota_memory VARCHAR(32),
    is_active           BOOLEAN DEFAULT TRUE,
    created_date        TIMESTAMP DEFAULT NOW(),
    created_by          VARCHAR(128),
    updated_date        TIMESTAMP DEFAULT NOW(),
    updated_by          VARCHAR(128)
);

-- ---------------------------------------------------------------------------

CREATE TABLE ml_schedule_config (
    schedule_id         SERIAL PRIMARY KEY,
    pipeline_id         INTEGER NOT NULL,            -- FK added after pipeline table
    schedule_name       VARCHAR(256),
    schedule_type       VARCHAR(32) NOT NULL
        CHECK (schedule_type IN ('cron','event','on_demand')),
    cron_expression     VARCHAR(128),
    event_trigger       JSONB,                       -- {type: 'feed_complete', feed_id: 8}
    timezone            VARCHAR(64) DEFAULT 'UTC',
    effective_start_date TIMESTAMP,
    effective_end_date  TIMESTAMP,
    max_concurrent_runs INTEGER DEFAULT 1,
    is_active           BOOLEAN DEFAULT TRUE,
    created_date        TIMESTAMP DEFAULT NOW(),
    created_by          VARCHAR(128),
    updated_date        TIMESTAMP DEFAULT NOW(),
    updated_by          VARCHAR(128)
);

-- ============================================================================
-- LAYER 5: PIPELINE & EXECUTION
-- ============================================================================

CREATE TABLE ml_pipeline_definition (
    pipeline_id         SERIAL PRIMARY KEY,
    project_id          INTEGER REFERENCES ml_project(project_id),
    pipeline_name       VARCHAR(256) NOT NULL,
    pipeline_code       VARCHAR(128) UNIQUE,
    pipeline_type       VARCHAR(64) NOT NULL
        CHECK (pipeline_type IN ('training','scoring','retraining','feature_engineering',
               'evaluation','etl_ml','monitoring','custom')),
    description         TEXT,
    dag_definition      JSONB,                       -- Step dependency graph
    default_compute_config_id INTEGER REFERENCES ml_compute_config(compute_config_id),
    retry_policy        JSONB DEFAULT '{"max_retries": 3, "backoff_seconds": 60}',
    timeout_minutes     INTEGER DEFAULT 360,
    notification_email_id VARCHAR(256),
    version             INTEGER DEFAULT 1,
    is_active           BOOLEAN DEFAULT TRUE,
    created_date        TIMESTAMP DEFAULT NOW(),
    created_by          VARCHAR(128),
    updated_date        TIMESTAMP DEFAULT NOW(),
    updated_by          VARCHAR(128)
);

-- Add FK for schedule_config now that pipeline exists
ALTER TABLE ml_schedule_config
    ADD CONSTRAINT fk_schedule_pipeline
    FOREIGN KEY (pipeline_id) REFERENCES ml_pipeline_definition(pipeline_id);

CREATE INDEX idx_ml_pipeline_project ON ml_pipeline_definition(project_id);
CREATE INDEX idx_ml_pipeline_type ON ml_pipeline_definition(pipeline_type);

-- ---------------------------------------------------------------------------

CREATE TABLE ml_pipeline_step (
    step_id             SERIAL PRIMARY KEY,
    pipeline_id         INTEGER NOT NULL REFERENCES ml_pipeline_definition(pipeline_id),
    step_name           VARCHAR(256) NOT NULL,
    step_order          INTEGER NOT NULL,
    step_type           VARCHAR(64) NOT NULL
        CHECK (step_type IN ('data_pull','feature_eng','train','evaluate','register',
               'deploy','quality_check','scoring','custom')),
    entry_point         VARCHAR(512),
    step_parameters     JSONB DEFAULT '{}',
    depends_on_steps    INTEGER[],                   -- Array of step_ids
    compute_config_id   INTEGER REFERENCES ml_compute_config(compute_config_id),
    timeout_minutes     INTEGER,
    is_optional         BOOLEAN DEFAULT FALSE,
    is_active           BOOLEAN DEFAULT TRUE,
    created_date        TIMESTAMP DEFAULT NOW(),
    created_by          VARCHAR(128)
);

CREATE INDEX idx_ml_step_pipeline ON ml_pipeline_step(pipeline_id);

-- ---------------------------------------------------------------------------

CREATE TABLE ml_pipeline_execution (
    execution_id        SERIAL PRIMARY KEY,
    pipeline_id         INTEGER NOT NULL REFERENCES ml_pipeline_definition(pipeline_id),
    run_id              INTEGER REFERENCES ml_experiment_run(run_id),
    execution_uuid      UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(),
    execution_status    VARCHAR(32) NOT NULL
        CHECK (execution_status IN ('queued','running','completed','failed',
               'killed','timeout','partial_success')),
    trigger_type        VARCHAR(32)
        CHECK (trigger_type IN ('manual','scheduled','event','drift_alert','api')),
    triggered_by        VARCHAR(128),
    schedule_id         INTEGER REFERENCES ml_schedule_config(schedule_id),
    runtime_parameters  JSONB DEFAULT '{}',
    start_time          TIMESTAMP,
    end_time            TIMESTAMP,
    duration_seconds    INTEGER,
    steps_total         INTEGER,
    steps_completed     INTEGER,
    steps_failed        INTEGER,
    error_message       TEXT,
    resource_usage      JSONB,                       -- {peak_memory_gb, cpu_hours, gpu_hours}
    created_date        TIMESTAMP DEFAULT NOW(),
    created_by          VARCHAR(128),
    updated_date        TIMESTAMP DEFAULT NOW(),
    updated_by          VARCHAR(128)
);

CREATE INDEX idx_ml_exec_pipeline ON ml_pipeline_execution(pipeline_id);
CREATE INDEX idx_ml_exec_status ON ml_pipeline_execution(execution_status);
CREATE INDEX idx_ml_exec_start ON ml_pipeline_execution(start_time DESC);

-- ---------------------------------------------------------------------------

CREATE TABLE ml_step_execution (
    step_execution_id   SERIAL PRIMARY KEY,
    execution_id        INTEGER NOT NULL REFERENCES ml_pipeline_execution(execution_id),
    step_id             INTEGER NOT NULL REFERENCES ml_pipeline_step(step_id),
    step_status         VARCHAR(32) NOT NULL
        CHECK (step_status IN ('queued','running','completed','failed','skipped','timeout')),
    attempt_number      INTEGER DEFAULT 1,
    input_artifact_uris JSONB,
    output_artifact_uris JSONB,
    step_metrics        JSONB,
    step_logs_uri       VARCHAR(1024),
    start_time          TIMESTAMP,
    end_time            TIMESTAMP,
    duration_seconds    INTEGER,
    error_message       TEXT,
    error_traceback     TEXT,
    resource_usage      JSONB,
    created_date        TIMESTAMP DEFAULT NOW(),
    created_by          VARCHAR(128)
);

CREATE INDEX idx_ml_stepexec_exec ON ml_step_execution(execution_id);
CREATE INDEX idx_ml_stepexec_status ON ml_step_execution(step_status);

-- ============================================================================
-- LAYER 6: QUALITY & MONITORING
-- ============================================================================

CREATE TABLE ml_quality_suite (
    suite_id            SERIAL PRIMARY KEY,
    suite_name          VARCHAR(256) NOT NULL UNIQUE,
    suite_type          VARCHAR(64) NOT NULL
        CHECK (suite_type IN ('data_quality','model_performance','feature_drift',
               'concept_drift','bias_fairness','custom')),
    description         TEXT,
    ge_expectation_suite_name VARCHAR(256),           -- Link to Great Expectations
    is_blocking         BOOLEAN DEFAULT TRUE,        -- Pipeline fails on breach
    notification_channel VARCHAR(128),
    is_active           BOOLEAN DEFAULT TRUE,
    created_date        TIMESTAMP DEFAULT NOW(),
    created_by          VARCHAR(128),
    updated_date        TIMESTAMP DEFAULT NOW(),
    updated_by          VARCHAR(128)
);

-- ---------------------------------------------------------------------------

CREATE TABLE ml_quality_check (
    check_id            SERIAL PRIMARY KEY,
    suite_id            INTEGER NOT NULL REFERENCES ml_quality_suite(suite_id),
    check_name          VARCHAR(256) NOT NULL,
    check_type          VARCHAR(64) NOT NULL
        CHECK (check_type IN ('ge_expectation','psi','csi','ks_test','auc_threshold',
               'recall_threshold','precision_threshold','custom_sql','custom_python')),
    check_config        JSONB NOT NULL,              -- Full check parameters
    severity            VARCHAR(16) NOT NULL
        CHECK (severity IN ('critical','warning','info')),
    threshold_value     NUMERIC(18,6),
    threshold_operator  VARCHAR(8)
        CHECK (threshold_operator IN ('gt','gte','lt','lte','eq','between')),
    threshold_upper     NUMERIC(18,6),
    is_active           BOOLEAN DEFAULT TRUE,
    created_date        TIMESTAMP DEFAULT NOW(),
    created_by          VARCHAR(128)
);

CREATE INDEX idx_ml_qcheck_suite ON ml_quality_check(suite_id);

-- ---------------------------------------------------------------------------

CREATE TABLE ml_quality_result (
    result_id           SERIAL PRIMARY KEY,
    check_id            INTEGER NOT NULL REFERENCES ml_quality_check(check_id),
    execution_id        INTEGER REFERENCES ml_pipeline_execution(execution_id),
    model_version_id    INTEGER REFERENCES ml_model_version(model_version_id),
    dataset_id          INTEGER REFERENCES ml_dataset_registry(dataset_id),
    check_status        VARCHAR(16) NOT NULL
        CHECK (check_status IN ('passed','failed','warning','error')),
    actual_value        NUMERIC(18,6),
    expected_value      NUMERIC(18,6),
    deviation_pct       NUMERIC(8,4),
    details             JSONB,                       -- Full GE ValidationResult or custom
    ge_run_id           VARCHAR(256),
    remediation_action  VARCHAR(64)
        CHECK (remediation_action IN ('none','pipeline_halted','alert_sent',
               'auto_retrain_triggered','manual_review')),
    evaluated_at        TIMESTAMP NOT NULL DEFAULT NOW(),
    created_date        TIMESTAMP DEFAULT NOW(),
    created_by          VARCHAR(128)
);

CREATE INDEX idx_ml_qresult_check ON ml_quality_result(check_id);
CREATE INDEX idx_ml_qresult_exec ON ml_quality_result(execution_id);
CREATE INDEX idx_ml_qresult_mv ON ml_quality_result(model_version_id);
CREATE INDEX idx_ml_qresult_status ON ml_quality_result(check_status);
CREATE INDEX idx_ml_qresult_eval ON ml_quality_result(evaluated_at DESC);

-- ---------------------------------------------------------------------------

CREATE TABLE ml_drift_monitor (
    monitor_id          SERIAL PRIMARY KEY,
    model_id            INTEGER NOT NULL REFERENCES ml_model_registry(model_id),
    monitor_name        VARCHAR(256),
    monitor_type        VARCHAR(64) NOT NULL
        CHECK (monitor_type IN ('data_drift','concept_drift','prediction_drift','feature_drift')),
    reference_dataset_id INTEGER REFERENCES ml_dataset_registry(dataset_id),
    reference_window    VARCHAR(64)
        CHECK (reference_window IN ('last_30d','last_90d','training_baseline','custom')),
    detection_method    VARCHAR(64)
        CHECK (detection_method IN ('psi','ks_test','wasserstein','js_divergence',
               'chi_squared','cramers_v','hellinger')),
    threshold           NUMERIC(8,4),
    evaluation_frequency VARCHAR(32)
        CHECK (evaluation_frequency IN ('daily','weekly','monthly','on_scoring_run')),
    auto_retrain_on_breach BOOLEAN DEFAULT FALSE,
    alert_channel       VARCHAR(128),
    is_active           BOOLEAN DEFAULT TRUE,
    created_date        TIMESTAMP DEFAULT NOW(),
    created_by          VARCHAR(128),
    updated_date        TIMESTAMP DEFAULT NOW(),
    updated_by          VARCHAR(128)
);

CREATE INDEX idx_ml_drift_model ON ml_drift_monitor(model_id);

-- ---------------------------------------------------------------------------

CREATE TABLE ml_drift_result (
    drift_result_id     SERIAL PRIMARY KEY,
    monitor_id          INTEGER NOT NULL REFERENCES ml_drift_monitor(monitor_id),
    model_version_id    INTEGER REFERENCES ml_model_version(model_version_id),
    evaluation_date     DATE NOT NULL,
    drift_score         NUMERIC(10,6),
    is_drift_detected   BOOLEAN NOT NULL,
    feature_drift_details JSONB,                     -- {feature_name: {psi: 0.23, status: 'drifted'}}
    reference_stats     JSONB,
    current_stats       JSONB,
    action_taken        VARCHAR(64)
        CHECK (action_taken IN ('none','alert_sent','retrain_triggered','model_retired','manual_review')),
    created_date        TIMESTAMP DEFAULT NOW(),
    created_by          VARCHAR(128)
);

CREATE INDEX idx_ml_driftres_monitor ON ml_drift_result(monitor_id);
CREATE INDEX idx_ml_driftres_date ON ml_drift_result(evaluation_date DESC);
CREATE INDEX idx_ml_driftres_drift ON ml_drift_result(is_drift_detected) WHERE is_drift_detected = TRUE;

-- ============================================================================
-- LAYER 7: SERVING & DEPLOYMENT
-- ============================================================================

CREATE TABLE ml_serving_endpoint (
    endpoint_id         SERIAL PRIMARY KEY,
    model_id            INTEGER NOT NULL REFERENCES ml_model_registry(model_id),
    active_model_version_id INTEGER REFERENCES ml_model_version(model_version_id),
    endpoint_name       VARCHAR(256) NOT NULL,
    endpoint_type       VARCHAR(32) NOT NULL
        CHECK (endpoint_type IN ('batch','rest_api','grpc','streaming')),
    endpoint_url        VARCHAR(1024),
    route_name          VARCHAR(256),                -- OpenShift route
    namespace           VARCHAR(128),
    compute_config_id   INTEGER REFERENCES ml_compute_config(compute_config_id),
    scaling_policy      JSONB,                       -- {min_replicas, max_replicas, target_rps}
    traffic_split       JSONB,                       -- {champion: 90, challenger: 10}
    health_check_path   VARCHAR(256),
    sla_latency_p99_ms  INTEGER,
    is_active           BOOLEAN DEFAULT TRUE,
    created_date        TIMESTAMP DEFAULT NOW(),
    created_by          VARCHAR(128),
    updated_date        TIMESTAMP DEFAULT NOW(),
    updated_by          VARCHAR(128)
);

CREATE INDEX idx_ml_endpoint_model ON ml_serving_endpoint(model_id);

-- ---------------------------------------------------------------------------

CREATE TABLE ml_deployment_history (
    deployment_id       SERIAL PRIMARY KEY,
    endpoint_id         INTEGER NOT NULL REFERENCES ml_serving_endpoint(endpoint_id),
    model_version_id    INTEGER NOT NULL REFERENCES ml_model_version(model_version_id),
    action              VARCHAR(32) NOT NULL
        CHECK (action IN ('deploy','rollback','scale','canary_promote','retire')),
    previous_model_version_id INTEGER REFERENCES ml_model_version(model_version_id),
    deployment_strategy VARCHAR(32)
        CHECK (deployment_strategy IN ('blue_green','canary','rolling','immediate')),
    deployment_status   VARCHAR(32)
        CHECK (deployment_status IN ('pending','in_progress','completed','failed','rolled_back')),
    health_check_passed BOOLEAN,
    smoke_test_passed   BOOLEAN,
    deployed_by         VARCHAR(128),
    deployment_notes    TEXT,
    deployed_at         TIMESTAMP DEFAULT NOW(),
    created_date        TIMESTAMP DEFAULT NOW(),
    created_by          VARCHAR(128)
);

CREATE INDEX idx_ml_deploy_endpoint ON ml_deployment_history(endpoint_id);
CREATE INDEX idx_ml_deploy_at ON ml_deployment_history(deployed_at DESC);

-- ---------------------------------------------------------------------------

CREATE TABLE ml_scoring_log (
    scoring_log_id      SERIAL PRIMARY KEY,
    execution_id        INTEGER REFERENCES ml_pipeline_execution(execution_id),
    endpoint_id         INTEGER REFERENCES ml_serving_endpoint(endpoint_id),
    model_version_id    INTEGER NOT NULL REFERENCES ml_model_version(model_version_id),
    dataset_id          INTEGER REFERENCES ml_dataset_registry(dataset_id),
    scoring_date        DATE NOT NULL,
    records_scored      BIGINT,
    records_failed      BIGINT,
    output_uri          VARCHAR(1024),
    avg_prediction      NUMERIC(10,6),
    prediction_distribution JSONB,                   -- Histogram bins for monitoring
    duration_seconds    INTEGER,
    created_date        TIMESTAMP DEFAULT NOW(),
    created_by          VARCHAR(128)
);

CREATE INDEX idx_ml_scoring_mv ON ml_scoring_log(model_version_id);
CREATE INDEX idx_ml_scoring_date ON ml_scoring_log(scoring_date DESC);

-- ============================================================================
-- BRIDGE TABLE: FEATURE → MODEL VERSION (which features fed which model)
-- ============================================================================

CREATE TABLE ml_model_feature_map (
    map_id              SERIAL PRIMARY KEY,
    model_version_id    INTEGER NOT NULL REFERENCES ml_model_version(model_version_id),
    feature_id          INTEGER NOT NULL REFERENCES ml_feature_definition(feature_id),
    feature_importance_rank INTEGER,
    importance_score    NUMERIC(10,6),
    is_active           BOOLEAN DEFAULT TRUE,
    created_date        TIMESTAMP DEFAULT NOW(),
    created_by          VARCHAR(128),

    UNIQUE (model_version_id, feature_id)
);

CREATE INDEX idx_ml_mfm_mv ON ml_model_feature_map(model_version_id);

-- ============================================================================
-- BRIDGE TABLE: QUALITY SUITE → PIPELINE STEP (attach checks to steps)
-- ============================================================================

CREATE TABLE ml_step_quality_binding (
    binding_id          SERIAL PRIMARY KEY,
    step_id             INTEGER NOT NULL REFERENCES ml_pipeline_step(step_id),
    suite_id            INTEGER NOT NULL REFERENCES ml_quality_suite(suite_id),
    execution_order     INTEGER DEFAULT 1,
    is_active           BOOLEAN DEFAULT TRUE,
    created_date        TIMESTAMP DEFAULT NOW(),
    created_by          VARCHAR(128),

    UNIQUE (step_id, suite_id)
);

-- ============================================================================
-- AUDIT TRIGGER (auto-set updated_date on any UPDATE)
-- ============================================================================

CREATE OR REPLACE FUNCTION ml_meta.set_updated_date()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_date = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply to all tables with updated_date column
DO $$
DECLARE
    tbl TEXT;
BEGIN
    FOR tbl IN
        SELECT table_name FROM information_schema.columns
        WHERE table_schema = 'ml_meta' AND column_name = 'updated_date'
    LOOP
        EXECUTE format(
            'CREATE TRIGGER trg_%s_updated BEFORE UPDATE ON ml_meta.%I
             FOR EACH ROW EXECUTE FUNCTION ml_meta.set_updated_date();',
            tbl, tbl
        );
    END LOOP;
END $$;

-- ============================================================================
-- COMMENTS
-- ============================================================================
COMMENT ON SCHEMA ml_meta IS 'ML/Analytics metadata architecture — experiment tracking, model registry, pipeline orchestration, quality monitoring, serving';
COMMENT ON TABLE ml_meta.ml_project IS 'Top-level organizational unit for ML initiatives — aligns with business unit/department structure from ingestion layer';
COMMENT ON TABLE ml_meta.ml_experiment_run IS 'Single execution record — correlates with MLflow run_uuid for bidirectional traceability';
COMMENT ON TABLE ml_meta.ml_model_version IS 'Immutable model snapshot with full approval workflow — champion/challenger lifecycle for credit risk SR11-7 compliance';
COMMENT ON TABLE ml_meta.ml_quality_suite IS 'Reusable quality check suite — bridges to Great Expectations via ge_expectation_suite_name, matching ingestion layer ge_validation_ref pattern';
COMMENT ON TABLE ml_meta.ml_drift_monitor IS 'Continuous monitoring for data & concept drift — supports PSI, KS, Wasserstein detection methods with auto-retrain triggers';
COMMENT ON TABLE ml_meta.ml_compute_config IS 'Compute resource templates — mirrors spark_submit_setting from ingestion layer with GPU and K8s extensions';
