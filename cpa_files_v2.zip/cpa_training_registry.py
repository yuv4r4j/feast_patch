"""
CPA XGBoost Training Pipeline (Model Registry version)
Trains model on N months of actuals, logs to Snowflake Model Registry
"""

import pandas as pd
import numpy as np
import json
import logging
from datetime import datetime, timedelta

from snowflake.snowpark.context import get_active_session
from snowflake.ml.registry import Registry
from xgboost import XGBRegressor
from sklearn.model_selection import TimeSeriesSplit, RandomizedSearchCV
from sklearn.metrics import mean_absolute_error, mean_squared_error, mean_absolute_percentage_error

log = logging.getLogger("cpa_train")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

# ── config ──
REPORTING_DATE = "2026-03-02"
LOOKBACK_MONTHS = 24
HOLDOUT_MONTHS = 2
CV_FOLDS = 5
N_ITER = 50

# registry location
REGISTRY_DB = "DB_RISK"
REGISTRY_SCHEMA = "RISK_SBX"
MODEL_NAME = "CPA_XGB_MODEL"

CAT_COLS = ["CPA_SOURCE", "ORGINAL_ANNUAL_FEE_CONFIG", "ORGINAL_CARD_NETWORK", "SUBCHANNEL_CODE"]

FEATURES = [
    *CAT_COLS,
    "MONTH", "QUARTER", "YEAR", "MONTHS_SINCE_START",
    "CPA_LAG_1", "CPA_LAG_2", "CPA_LAG_3",
    "CPA_ROLLING_3M_MEAN", "CPA_ROLLING_3M_STD",
    "CREDIT_LINE_BIN",
]

TARGET = "CPA_AMOUNT"

PARAM_GRID = {
    "n_estimators": [100, 200, 300, 500],
    "max_depth": [3, 4, 5, 6],
    "learning_rate": [0.01, 0.05, 0.1],
    "subsample": [0.7, 0.8, 0.9],
    "colsample_bytree": [0.7, 0.8, 0.9],
    "min_child_weight": [1, 3, 5],
    "reg_alpha": [0, 0.1, 1.0],
    "reg_lambda": [1.0, 5.0, 10.0],
}


def get_actuals(session, lookback):
    q = f"""
        SELECT * FROM CSTONE_BIZ.RISK.PTI_FACT_CPA
        WHERE comment = 'actuals'
          AND to_date(ACCOUNT_OPEN_MONTH, 'DDMONYYYY') >= DATEADD('month', -{lookback}, CURRENT_DATE())
    """
    df = session.sql(q).to_pandas()
    df["REPORTING_DATE"] = pd.to_datetime(df["ACCOUNT_OPEN_MONTH"], format="%d%b%Y")
    df.drop(columns=["ACCOUNT_OPEN_MONTH"], inplace=True, errors="ignore")
    log.info(f"pulled {len(df):,} rows | {df['REPORTING_DATE'].min().date()} to {df['REPORTING_DATE'].max().date()}")
    return df


def build_features(df):
    df = df.copy()
    df["REPORTING_DATE"] = pd.to_datetime(df["REPORTING_DATE"])
    df = df.sort_values(["CPA_SOURCE", "REPORTING_DATE"]).reset_index(drop=True)

    # time
    df["MONTH"] = df["REPORTING_DATE"].dt.month
    df["QUARTER"] = df["REPORTING_DATE"].dt.quarter
    df["YEAR"] = df["REPORTING_DATE"].dt.year
    df["MONTHS_SINCE_START"] = (
        (df["REPORTING_DATE"].dt.year - df["REPORTING_DATE"].dt.year.min()) * 12
        + df["REPORTING_DATE"].dt.month
    )

    # lags per source
    for lag in [1, 2, 3]:
        df[f"CPA_LAG_{lag}"] = df.groupby("CPA_SOURCE")[TARGET].shift(lag)

    # rolling stats per source
    for src, grp in df.groupby("CPA_SOURCE"):
        mask = df["CPA_SOURCE"] == src
        df.loc[mask, "CPA_ROLLING_3M_MEAN"] = grp[TARGET].rolling(3, min_periods=1).mean().values
        df.loc[mask, "CPA_ROLLING_3M_STD"] = grp[TARGET].rolling(3, min_periods=1).std().fillna(0).values

    # credit line buckets
    if "ORIGINAL_CREDIT_LINE" in df.columns:
        df["CREDIT_LINE_BIN"] = pd.cut(
            df["ORIGINAL_CREDIT_LINE"],
            bins=[0, 300, 500, 750, 1000, 2000, 5000, np.inf],
            labels=[0, 1, 2, 3, 4, 5, 6],
        ).astype(float)
    else:
        df["CREDIT_LINE_BIN"] = 0.0

    for c in CAT_COLS:
        if c in df.columns:
            df[c] = df[c].astype("category")

    before = len(df)
    df = df.dropna(subset=["CPA_LAG_1"])
    log.info(f"dropped {before - len(df):,} rows without lag history")
    return df


def temporal_split(df, holdout=2):
    """train on past, test on most recent N months"""
    df = df.sort_values("REPORTING_DATE")
    cutoff = df["REPORTING_DATE"].max() - pd.DateOffset(months=holdout)
    train = df[df["REPORTING_DATE"] <= cutoff].copy()
    test = df[df["REPORTING_DATE"] > cutoff].copy()
    log.info(f"train: {len(train):,} | test: {len(test):,}")
    if len(train) < 100:
        log.warning("training set looks thin — bump LOOKBACK_MONTHS?")
    return train, test


def fit_model(X_train, y_train):
    tscv = TimeSeriesSplit(n_splits=CV_FOLDS)
    base = XGBRegressor(
        enable_categorical=True,
        objective="reg:squarederror",
        tree_method="hist",
        random_state=42,
    )
    search = RandomizedSearchCV(
        base, PARAM_GRID,
        n_iter=N_ITER, cv=tscv,
        scoring="neg_mean_absolute_error",
        random_state=42, n_jobs=-1, verbose=0,
    )
    search.fit(X_train, y_train)
    log.info(f"best CV MAE: {-search.best_score_:,.4f}")
    log.info(f"best params: {search.best_params_}")
    return search


def evaluate(model, X_test, y_test, test_df):
    preds = np.clip(model.predict(X_test), 0, None)

    mae = mean_absolute_error(y_test, preds)
    rmse = np.sqrt(mean_squared_error(y_test, preds))
    mape = mean_absolute_percentage_error(y_test, preds)
    log.info(f"test MAE: {mae:,.4f} | RMSE: {rmse:,.4f} | MAPE: {mape:.2%}")

    # naive baseline
    metrics = {"mae": float(mae), "rmse": float(rmse), "mape": float(mape)}
    if "CPA_LAG_1" in test_df.columns:
        baseline = mean_absolute_error(y_test, test_df["CPA_LAG_1"])
        improvement = (baseline - mae) / baseline
        log.info(f"baseline MAE (lag1): {baseline:,.4f} | improvement: {improvement:.1%}")
        metrics["baseline_mae"] = float(baseline)
        metrics["improvement_pct"] = float(improvement * 100)

    # per source
    eval_df = test_df.copy()
    eval_df["PRED"] = preds
    log.info(f"{'SOURCE':<16} {'MAE':>10} {'N':>8}")
    for src, grp in eval_df.groupby("CPA_SOURCE"):
        src_mae = mean_absolute_error(grp[TARGET], grp["PRED"])
        log.info(f"{str(src):<16} {src_mae:>10,.2f} {len(grp):>8,}")

    # feature importance
    best = model.best_estimator_ if hasattr(model, "best_estimator_") else model
    imp = pd.Series(best.feature_importances_, index=FEATURES).sort_values(ascending=False)
    log.info("top features:")
    for f, v in imp.head(6).items():
        log.info(f"  {f:<25} {v:.4f}")

    return metrics


def generate_version_name():
    """version name based on reporting date + timestamp"""
    ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    rpt = REPORTING_DATE.replace("-", "")
    return f"V_{rpt}_{ts}"


def log_to_registry(session, model, metrics, X_train):
    """log fitted model to snowflake model registry with metrics and metadata"""
    reg = Registry(session=session, database_name=REGISTRY_DB, schema_name=REGISTRY_SCHEMA)

    best = model.best_estimator_ if hasattr(model, "best_estimator_") else model
    version = generate_version_name()

    # add training metadata to metrics dict
    metrics["reporting_date"] = REPORTING_DATE
    metrics["lookback_months"] = LOOKBACK_MONTHS
    metrics["holdout_months"] = HOLDOUT_MONTHS
    metrics["training_rows"] = int(X_train.shape[0])
    metrics["n_features"] = int(X_train.shape[1])
    if hasattr(model, "best_params_"):
        metrics["best_params"] = json.dumps(model.best_params_)
    if hasattr(model, "best_score_"):
        metrics["best_cv_mae"] = float(-model.best_score_)

    log.info(f"logging to registry: {REGISTRY_DB}.{REGISTRY_SCHEMA}.{MODEL_NAME} version={version}")

    # xgboost is natively supported — just pass the fitted estimator
    # sample_input_data lets registry infer the input signature
    mv = reg.log_model(
        model=best,
        model_name=MODEL_NAME,
        version_name=version,
        metrics=metrics,
        sample_input_data=X_train.head(10),
        comment=f"CPA forecast model | {REPORTING_DATE} | MAE={metrics['mae']:.4f}",
    )

    # set as default so inference picks it up automatically
    m = reg.get_model(MODEL_NAME)
    m.default = version
    log.info(f"set default version: {version}")

    # list recent versions for visibility
    log.info("current versions:")
    for v in m.versions():
        is_default = " (default)" if v.version_name == version else ""
        log.info(f"  {v.version_name}{is_default}")

    return mv


def run(session=None):
    if session is None:
        session = get_active_session()

    log.info(f"=== CPA TRAINING | {REPORTING_DATE} | {LOOKBACK_MONTHS}mo lookback ===")

    raw = get_actuals(session, LOOKBACK_MONTHS)
    df = build_features(raw)
    train_df, test_df = temporal_split(df, HOLDOUT_MONTHS)

    avail = [c for c in FEATURES if c in train_df.columns]
    X_train, y_train = train_df[avail], train_df[TARGET]
    X_test, y_test = test_df[avail], test_df[TARGET]

    search = fit_model(X_train, y_train)
    metrics = evaluate(search, X_test, y_test, test_df)

    # log to model registry instead of manual stage upload
    mv = log_to_registry(session, search, metrics, X_train)

    log.info(f"done. model logged to {REGISTRY_DB}.{REGISTRY_SCHEMA}.{MODEL_NAME}")
    return mv


if __name__ == "__main__":
    run(get_active_session())
