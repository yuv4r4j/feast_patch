# ghorg one-time GitLab clone on OpenShift

Edit `secret.yaml` (your token) and `job.yaml` (your group path / base-url)
before applying.

## Run the clone job

```bash
oc apply -f secret.yaml
oc apply -f pvc.yaml
oc apply -f job.yaml
oc logs -f job/ghorg-clone
```

## Pull the cloned repos out to your machine

```bash
oc apply -f extract-pod.yaml
oc rsync ghorg-extract:/data ./local-repos
oc delete pod ghorg-extract
```

## Clean up

```bash
oc delete job ghorg-clone
oc delete pvc ghorg-repos
```

## If you hit permission errors

OpenShift's default `restricted` SCC runs containers as an arbitrary
non-root UID. `HOME=/data` in job.yaml works around most of this. If it's
still failing, check the UID the pod ran as and, as a fallback, grant the
`anyuid` SCC to the job's service account:

```bash
oc adm policy add-scc-to-user anyuid -z default
```
